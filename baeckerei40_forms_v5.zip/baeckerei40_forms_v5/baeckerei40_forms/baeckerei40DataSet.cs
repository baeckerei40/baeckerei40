﻿namespace baeckerei40_forms
{


    partial class baeckerei40DataSet
    {
        partial class MitarbeiterDataTable
        {
        }
    }
}

namespace baeckerei40_forms.baeckerei40DataSetTableAdapters
{
    partial class KundenTableAdapter
    {
    }

    public partial class BestellungenTableAdapter {
    }
}
