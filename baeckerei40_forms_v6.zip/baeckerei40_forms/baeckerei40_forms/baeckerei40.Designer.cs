﻿namespace baeckerei40_forms
{
    partial class baeckerei40
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelBenutzer = new System.Windows.Forms.Label();
            this.tabPageControlling = new System.Windows.Forms.TabPage();
            this.tabPageRohstoffe = new System.Windows.Forms.TabPage();
            this.RezSp = new System.Windows.Forms.Button();
            this.RezHinzu = new System.Windows.Forms.Button();
            this.RezBearb = new System.Windows.Forms.Button();
            this.RezAbbr = new System.Windows.Forms.Button();
            this.panelRez = new System.Windows.Forms.GroupBox();
            this.Roheinheit3 = new System.Windows.Forms.TextBox();
            this.rezeptverwaltungBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet5 = new baeckerei40_forms.baeckerei40DataSet5();
            this.Rohmenge3 = new System.Windows.Forms.TextBox();
            this.Rohname3 = new System.Windows.Forms.TextBox();
            this.Roheinheit2 = new System.Windows.Forms.TextBox();
            this.Rohmenge2 = new System.Windows.Forms.TextBox();
            this.Rohname2 = new System.Windows.Forms.TextBox();
            this.Roheinheit1 = new System.Windows.Forms.TextBox();
            this.Rohmenge1 = new System.Windows.Forms.TextBox();
            this.Rohname1 = new System.Windows.Forms.TextBox();
            this.Roheinheit = new System.Windows.Forms.TextBox();
            this.Rohmenge = new System.Windows.Forms.TextBox();
            this.Rohname = new System.Windows.Forms.TextBox();
            this.Rezname = new System.Windows.Forms.TextBox();
            this.RezID = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.RezeptID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RezeptName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rezeptIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rezeptNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffmengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffEinheitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffname1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffmenge1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffEinheit1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffname2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffmenge2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffEinheit2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffname3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffmenge3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffEinheit3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktEnthaeltBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet4 = new baeckerei40_forms.baeckerei40DataSet4();
            this.tabPageKomissionierung = new System.Windows.Forms.TabPage();
            this.panelKom = new System.Windows.Forms.Panel();
            this.tb_BestellID = new System.Windows.Forms.TextBox();
            this.bestellungenBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet10 = new baeckerei40_forms.baeckerei40DataSet10();
            this.Kom_GPreis = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.Kom_speichern = new System.Windows.Forms.Button();
            this.Kom_bearb = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.bestellIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kundenIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abholdatumDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abholzeitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkbox = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button_mult = new System.Windows.Forms.Button();
            this.button_istgleich = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.textBox_anzeige = new System.Windows.Forms.TextBox();
            this.btn_minus = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dataGridViewPL = new System.Windows.Forms.DataGridView();
            this.produktIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktPreisDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produkteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet6 = new baeckerei40_forms.baeckerei40DataSet6();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellIDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktIDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellMengeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellungEnthaeltBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet9 = new baeckerei40_forms.baeckerei40DataSet9();
            this.bestellungenBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet8 = new baeckerei40_forms.baeckerei40DataSet8();
            this.tabPageLager = new System.Windows.Forms.TabPage();
            this.RSpeichern = new System.Windows.Forms.Button();
            this.panel = new System.Windows.Forms.GroupBox();
            this.labeli = new System.Windows.Forms.Label();
            this.RID = new System.Windows.Forms.TextBox();
            this.rohstoffeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet1 = new baeckerei40_forms.baeckerei40DataSet1();
            this.RPreis = new System.Windows.Forms.TextBox();
            this.REinheit = new System.Windows.Forms.TextBox();
            this.LMenge = new System.Windows.Forms.TextBox();
            this.RName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridViewLager = new System.Windows.Forms.DataGridView();
            this.rohstoffIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffeinheitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffPreisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lagermengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RHinzufügen = new System.Windows.Forms.Button();
            this.RBearbeiten = new System.Windows.Forms.Button();
            this.RAbbrechen = new System.Windows.Forms.Button();
            this.tabPageProduktion = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridViewProduktionsliste = new System.Windows.Forms.DataGridView();
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellMengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produziertDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bestellungEnthaeltBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet = new baeckerei40_forms.baeckerei40DataSet();
            this.buttonProduktionSpeichern = new System.Windows.Forms.Button();
            this.tabPageBestellung = new System.Windows.Forms.TabPage();
            this.buttonWarenkorbHinzufuegen = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridViewBestellliste = new System.Windows.Forms.DataGridView();
            this.KundenID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Abholdatum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Abholzeit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellungenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonBestelllisteSpeichern = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonBestellen = new System.Windows.Forms.Button();
            this.labelGesamtpreis = new System.Windows.Forms.Label();
            this.buttonWarenkorbEntfernen = new System.Windows.Forms.Button();
            this.labelWarenkorb = new System.Windows.Forms.Label();
            this.dateTimePickerAbholzeit = new System.Windows.Forms.DateTimePicker();
            this.labelAbholzeit = new System.Windows.Forms.Label();
            this.listBoxWarenkorb = new System.Windows.Forms.ListBox();
            this.labelAbholdatum = new System.Windows.Forms.Label();
            this.dateTimePickerAbholdatum = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonAenderungProduktliste = new System.Windows.Forms.Button();
            this.dataGridViewProduktliste = new System.Windows.Forms.DataGridView();
            this.produktIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktPreisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produkteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonKundeHinzufügen = new System.Windows.Forms.Button();
            this.buttonBearbeiten = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.dataGridKundenliste = new System.Windows.Forms.DataGridView();
            this.kundenIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vornameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nachnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonnummerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pLZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kundenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBoxKundennummer = new System.Windows.Forms.TextBox();
            this.labelKundennummer = new System.Windows.Forms.Label();
            this.textBoxTelefonnummer = new System.Windows.Forms.TextBox();
            this.labelTelefonnummer = new System.Windows.Forms.Label();
            this.textBoxNachname = new System.Windows.Forms.TextBox();
            this.labelNachname = new System.Windows.Forms.Label();
            this.textBoxVorname = new System.Windows.Forms.TextBox();
            this.labelVorname = new System.Windows.Forms.Label();
            this.bestellungenPodukteInBestellungenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabControlWrapper = new System.Windows.Forms.TabControl();
            this.kundenTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.KundenTableAdapter();
            this.produkteTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.ProdukteTableAdapter();
            this.bestellungenTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.BestellungenTableAdapter();
            this.bestellungEnthaeltTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.BestellungEnthaeltTableAdapter();
            this.baeckerei40DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rohstoffeTableAdapter = new baeckerei40_forms.baeckerei40DataSet1TableAdapters.RohstoffeTableAdapter();
            this.produktEnthaeltTableAdapter = new baeckerei40_forms.baeckerei40DataSet4TableAdapters.ProduktEnthaeltTableAdapter();
            this.rezeptverwaltungTableAdapter = new baeckerei40_forms.baeckerei40DataSet5TableAdapters.RezeptverwaltungTableAdapter();
            this.produkteTableAdapter1 = new baeckerei40_forms.baeckerei40DataSet6TableAdapters.ProdukteTableAdapter();
            this.bestellungenTableAdapter1 = new baeckerei40_forms.baeckerei40DataSet8TableAdapters.BestellungenTableAdapter();
            this.bestellungEnthaeltTableAdapter1 = new baeckerei40_forms.baeckerei40DataSet9TableAdapters.BestellungEnthaeltTableAdapter();
            this.bestellungenTableAdapter2 = new baeckerei40_forms.baeckerei40DataSet10TableAdapters.BestellungenTableAdapter();
            this.tabPageRohstoffe.SuspendLayout();
            this.panelRez.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet5)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produktEnthaeltBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet4)).BeginInit();
            this.tabPageKomissionierung.SuspendLayout();
            this.panelKom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet8)).BeginInit();
            this.tabPageLager.SuspendLayout();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rohstoffeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet1)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLager)).BeginInit();
            this.tabPageProduktion.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktionsliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet)).BeginInit();
            this.tabPageBestellung.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridKundenliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenPodukteInBestellungenBindingSource)).BeginInit();
            this.tabControlWrapper.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // labelBenutzer
            // 
            this.labelBenutzer.AutoSize = true;
            this.labelBenutzer.Location = new System.Drawing.Point(873, 9);
            this.labelBenutzer.Name = "labelBenutzer";
            this.labelBenutzer.Size = new System.Drawing.Size(55, 13);
            this.labelBenutzer.TabIndex = 1;
            this.labelBenutzer.Text = "Benutzer: ";
            // 
            // tabPageControlling
            // 
            this.tabPageControlling.Location = new System.Drawing.Point(4, 22);
            this.tabPageControlling.Name = "tabPageControlling";
            this.tabPageControlling.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageControlling.Size = new System.Drawing.Size(993, 691);
            this.tabPageControlling.TabIndex = 6;
            this.tabPageControlling.Text = "Controlling";
            this.tabPageControlling.UseVisualStyleBackColor = true;
            // 
            // tabPageRohstoffe
            // 
            this.tabPageRohstoffe.Controls.Add(this.RezSp);
            this.tabPageRohstoffe.Controls.Add(this.RezHinzu);
            this.tabPageRohstoffe.Controls.Add(this.RezBearb);
            this.tabPageRohstoffe.Controls.Add(this.RezAbbr);
            this.tabPageRohstoffe.Controls.Add(this.panelRez);
            this.tabPageRohstoffe.Controls.Add(this.groupBox13);
            this.tabPageRohstoffe.Location = new System.Drawing.Point(4, 22);
            this.tabPageRohstoffe.Name = "tabPageRohstoffe";
            this.tabPageRohstoffe.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRohstoffe.Size = new System.Drawing.Size(993, 691);
            this.tabPageRohstoffe.TabIndex = 5;
            this.tabPageRohstoffe.Text = "Rezepte";
            this.tabPageRohstoffe.UseVisualStyleBackColor = true;
            // 
            // RezSp
            // 
            this.RezSp.Location = new System.Drawing.Point(826, 566);
            this.RezSp.Name = "RezSp";
            this.RezSp.Size = new System.Drawing.Size(97, 55);
            this.RezSp.TabIndex = 17;
            this.RezSp.Text = "Speichern";
            this.RezSp.UseVisualStyleBackColor = true;
            this.RezSp.Click += new System.EventHandler(this.RezSp_Click);
            // 
            // RezHinzu
            // 
            this.RezHinzu.Location = new System.Drawing.Point(826, 378);
            this.RezHinzu.Name = "RezHinzu";
            this.RezHinzu.Size = new System.Drawing.Size(97, 49);
            this.RezHinzu.TabIndex = 14;
            this.RezHinzu.Text = "Hinzufügen";
            this.RezHinzu.UseVisualStyleBackColor = true;
            this.RezHinzu.Click += new System.EventHandler(this.RezHinzu_Click);
            // 
            // RezBearb
            // 
            this.RezBearb.Location = new System.Drawing.Point(826, 439);
            this.RezBearb.Name = "RezBearb";
            this.RezBearb.Size = new System.Drawing.Size(97, 51);
            this.RezBearb.TabIndex = 16;
            this.RezBearb.Text = "Bearbeiten";
            this.RezBearb.UseVisualStyleBackColor = true;
            this.RezBearb.Click += new System.EventHandler(this.RezBearb_Click);
            // 
            // RezAbbr
            // 
            this.RezAbbr.Location = new System.Drawing.Point(826, 498);
            this.RezAbbr.Name = "RezAbbr";
            this.RezAbbr.Size = new System.Drawing.Size(97, 48);
            this.RezAbbr.TabIndex = 15;
            this.RezAbbr.Text = "Abbrechen";
            this.RezAbbr.UseVisualStyleBackColor = true;
            this.RezAbbr.Click += new System.EventHandler(this.RezAbbr_Click);
            // 
            // panelRez
            // 
            this.panelRez.Controls.Add(this.Roheinheit3);
            this.panelRez.Controls.Add(this.Rohmenge3);
            this.panelRez.Controls.Add(this.Rohname3);
            this.panelRez.Controls.Add(this.Roheinheit2);
            this.panelRez.Controls.Add(this.Rohmenge2);
            this.panelRez.Controls.Add(this.Rohname2);
            this.panelRez.Controls.Add(this.Roheinheit1);
            this.panelRez.Controls.Add(this.Rohmenge1);
            this.panelRez.Controls.Add(this.Rohname1);
            this.panelRez.Controls.Add(this.Roheinheit);
            this.panelRez.Controls.Add(this.Rohmenge);
            this.panelRez.Controls.Add(this.Rohname);
            this.panelRez.Controls.Add(this.Rezname);
            this.panelRez.Controls.Add(this.RezID);
            this.panelRez.Controls.Add(this.label16);
            this.panelRez.Controls.Add(this.label17);
            this.panelRez.Controls.Add(this.label18);
            this.panelRez.Controls.Add(this.label13);
            this.panelRez.Controls.Add(this.label14);
            this.panelRez.Controls.Add(this.label15);
            this.panelRez.Controls.Add(this.label10);
            this.panelRez.Controls.Add(this.label11);
            this.panelRez.Controls.Add(this.label12);
            this.panelRez.Controls.Add(this.label9);
            this.panelRez.Controls.Add(this.label7);
            this.panelRez.Controls.Add(this.label8);
            this.panelRez.Controls.Add(this.label6);
            this.panelRez.Controls.Add(this.label5);
            this.panelRez.Location = new System.Drawing.Point(7, 364);
            this.panelRez.Name = "panelRez";
            this.panelRez.Size = new System.Drawing.Size(747, 220);
            this.panelRez.TabIndex = 1;
            this.panelRez.TabStop = false;
            this.panelRez.Text = "Rezeptanzeige";
            // 
            // Roheinheit3
            // 
            this.Roheinheit3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RohstoffEinheit3", true));
            this.Roheinheit3.Location = new System.Drawing.Point(637, 173);
            this.Roheinheit3.Name = "Roheinheit3";
            this.Roheinheit3.Size = new System.Drawing.Size(100, 20);
            this.Roheinheit3.TabIndex = 27;
            // 
            // rezeptverwaltungBindingSource
            // 
            this.rezeptverwaltungBindingSource.DataMember = "Rezeptverwaltung";
            this.rezeptverwaltungBindingSource.DataSource = this.baeckerei40DataSet5;
            // 
            // baeckerei40DataSet5
            // 
            this.baeckerei40DataSet5.DataSetName = "baeckerei40DataSet5";
            this.baeckerei40DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Rohmenge3
            // 
            this.Rohmenge3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffmenge3", true));
            this.Rohmenge3.Location = new System.Drawing.Point(637, 110);
            this.Rohmenge3.Name = "Rohmenge3";
            this.Rohmenge3.Size = new System.Drawing.Size(100, 20);
            this.Rohmenge3.TabIndex = 26;
            // 
            // Rohname3
            // 
            this.Rohname3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffname3", true));
            this.Rohname3.Location = new System.Drawing.Point(637, 55);
            this.Rohname3.Name = "Rohname3";
            this.Rohname3.Size = new System.Drawing.Size(100, 20);
            this.Rohname3.TabIndex = 25;
            // 
            // Roheinheit2
            // 
            this.Roheinheit2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RohstoffEinheit2", true));
            this.Roheinheit2.Location = new System.Drawing.Point(476, 173);
            this.Roheinheit2.Name = "Roheinheit2";
            this.Roheinheit2.Size = new System.Drawing.Size(100, 20);
            this.Roheinheit2.TabIndex = 24;
            // 
            // Rohmenge2
            // 
            this.Rohmenge2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffmenge2", true));
            this.Rohmenge2.Location = new System.Drawing.Point(476, 110);
            this.Rohmenge2.Name = "Rohmenge2";
            this.Rohmenge2.Size = new System.Drawing.Size(100, 20);
            this.Rohmenge2.TabIndex = 23;
            // 
            // Rohname2
            // 
            this.Rohname2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffname2", true));
            this.Rohname2.Location = new System.Drawing.Point(476, 55);
            this.Rohname2.Name = "Rohname2";
            this.Rohname2.Size = new System.Drawing.Size(100, 20);
            this.Rohname2.TabIndex = 22;
            // 
            // Roheinheit1
            // 
            this.Roheinheit1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RohstoffEinheit1", true));
            this.Roheinheit1.Location = new System.Drawing.Point(332, 173);
            this.Roheinheit1.Name = "Roheinheit1";
            this.Roheinheit1.Size = new System.Drawing.Size(100, 20);
            this.Roheinheit1.TabIndex = 21;
            // 
            // Rohmenge1
            // 
            this.Rohmenge1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffmenge1", true));
            this.Rohmenge1.Location = new System.Drawing.Point(332, 110);
            this.Rohmenge1.Name = "Rohmenge1";
            this.Rohmenge1.Size = new System.Drawing.Size(100, 20);
            this.Rohmenge1.TabIndex = 20;
            // 
            // Rohname1
            // 
            this.Rohname1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffname1", true));
            this.Rohname1.Location = new System.Drawing.Point(332, 55);
            this.Rohname1.Name = "Rohname1";
            this.Rohname1.Size = new System.Drawing.Size(100, 20);
            this.Rohname1.TabIndex = 19;
            // 
            // Roheinheit
            // 
            this.Roheinheit.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RohstoffEinheit", true));
            this.Roheinheit.Location = new System.Drawing.Point(183, 173);
            this.Roheinheit.Name = "Roheinheit";
            this.Roheinheit.Size = new System.Drawing.Size(100, 20);
            this.Roheinheit.TabIndex = 18;
            // 
            // Rohmenge
            // 
            this.Rohmenge.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffmenge", true));
            this.Rohmenge.Location = new System.Drawing.Point(183, 110);
            this.Rohmenge.Name = "Rohmenge";
            this.Rohmenge.Size = new System.Drawing.Size(100, 20);
            this.Rohmenge.TabIndex = 17;
            // 
            // Rohname
            // 
            this.Rohname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "Rohstoffname", true));
            this.Rohname.Location = new System.Drawing.Point(183, 55);
            this.Rohname.Name = "Rohname";
            this.Rohname.Size = new System.Drawing.Size(100, 20);
            this.Rohname.TabIndex = 16;
            // 
            // Rezname
            // 
            this.Rezname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RezeptName", true));
            this.Rezname.Location = new System.Drawing.Point(10, 110);
            this.Rezname.Name = "Rezname";
            this.Rezname.Size = new System.Drawing.Size(100, 20);
            this.Rezname.TabIndex = 15;
            // 
            // RezID
            // 
            this.RezID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rezeptverwaltungBindingSource, "RezeptID", true));
            this.RezID.Location = new System.Drawing.Point(10, 55);
            this.RezID.Name = "RezID";
            this.RezID.Size = new System.Drawing.Size(100, 20);
            this.RezID.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(634, 157);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Rohstoffeinheit3";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(634, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 13);
            this.label17.TabIndex = 12;
            this.label17.Text = "Rohstoffmenge3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(634, 29);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 13);
            this.label18.TabIndex = 11;
            this.label18.Text = "Rohstoffname3";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(473, 157);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Rohstoffeinheit2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(473, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Rohstoffmenge2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(473, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "Rohstoffname2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(329, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Rohstoffeinheit1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(329, 94);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Rohstoffmenge1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(329, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Rohstoffname1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(180, 157);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Rohstoffeinheit";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(180, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Rohstoffmenge";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(180, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Rohstoffname";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Rezeptname";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "RezeptID";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.dataGridView2);
            this.groupBox13.Location = new System.Drawing.Point(7, 7);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(980, 351);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Rezptliste";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RezeptID,
            this.RezeptName,
            this.Rohstoffname,
            this.Rohstoffmenge,
            this.RohstoffEinheit,
            this.Rohstoffname1,
            this.Rohstoffmenge1,
            this.RohstoffEinheit1,
            this.Rohstoffname2,
            this.Rohstoffmenge2,
            this.RohstoffEinheit2,
            this.Rohstoffname3,
            this.Rohstoffmenge3,
            this.RohstoffEinheit3,
            this.rezeptIDDataGridViewTextBoxColumn,
            this.rezeptNameDataGridViewTextBoxColumn,
            this.rohstoffnameDataGridViewTextBoxColumn1,
            this.rohstoffmengeDataGridViewTextBoxColumn,
            this.rohstoffEinheitDataGridViewTextBoxColumn1,
            this.rohstoffname1DataGridViewTextBoxColumn,
            this.rohstoffmenge1DataGridViewTextBoxColumn,
            this.rohstoffEinheit1DataGridViewTextBoxColumn,
            this.rohstoffname2DataGridViewTextBoxColumn,
            this.rohstoffmenge2DataGridViewTextBoxColumn,
            this.rohstoffEinheit2DataGridViewTextBoxColumn,
            this.rohstoffname3DataGridViewTextBoxColumn,
            this.rohstoffmenge3DataGridViewTextBoxColumn,
            this.rohstoffEinheit3DataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.rezeptverwaltungBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(6, 30);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(968, 315);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView2_KeyDown);
            // 
            // RezeptID
            // 
            this.RezeptID.DataPropertyName = "RezeptID";
            this.RezeptID.HeaderText = "RezeptID";
            this.RezeptID.Name = "RezeptID";
            // 
            // RezeptName
            // 
            this.RezeptName.DataPropertyName = "RezeptName";
            this.RezeptName.HeaderText = "RezeptName";
            this.RezeptName.Name = "RezeptName";
            // 
            // Rohstoffname
            // 
            this.Rohstoffname.DataPropertyName = "Rohstoffname";
            this.Rohstoffname.HeaderText = "Rohstoffname";
            this.Rohstoffname.Name = "Rohstoffname";
            // 
            // Rohstoffmenge
            // 
            this.Rohstoffmenge.DataPropertyName = "Rohstoffmenge";
            this.Rohstoffmenge.HeaderText = "Rohstoffmenge";
            this.Rohstoffmenge.Name = "Rohstoffmenge";
            // 
            // RohstoffEinheit
            // 
            this.RohstoffEinheit.DataPropertyName = "RohstoffEinheit";
            this.RohstoffEinheit.HeaderText = "RohstoffEinheit";
            this.RohstoffEinheit.Name = "RohstoffEinheit";
            // 
            // Rohstoffname1
            // 
            this.Rohstoffname1.DataPropertyName = "Rohstoffname1";
            this.Rohstoffname1.HeaderText = "Rohstoffname1";
            this.Rohstoffname1.Name = "Rohstoffname1";
            // 
            // Rohstoffmenge1
            // 
            this.Rohstoffmenge1.DataPropertyName = "Rohstoffmenge1";
            this.Rohstoffmenge1.HeaderText = "Rohstoffmenge1";
            this.Rohstoffmenge1.Name = "Rohstoffmenge1";
            // 
            // RohstoffEinheit1
            // 
            this.RohstoffEinheit1.DataPropertyName = "RohstoffEinheit1";
            this.RohstoffEinheit1.HeaderText = "RohstoffEinheit1";
            this.RohstoffEinheit1.Name = "RohstoffEinheit1";
            // 
            // Rohstoffname2
            // 
            this.Rohstoffname2.DataPropertyName = "Rohstoffname2";
            this.Rohstoffname2.HeaderText = "Rohstoffname2";
            this.Rohstoffname2.Name = "Rohstoffname2";
            // 
            // Rohstoffmenge2
            // 
            this.Rohstoffmenge2.DataPropertyName = "Rohstoffmenge2";
            this.Rohstoffmenge2.HeaderText = "Rohstoffmenge2";
            this.Rohstoffmenge2.Name = "Rohstoffmenge2";
            // 
            // RohstoffEinheit2
            // 
            this.RohstoffEinheit2.DataPropertyName = "RohstoffEinheit2";
            this.RohstoffEinheit2.HeaderText = "RohstoffEinheit2";
            this.RohstoffEinheit2.Name = "RohstoffEinheit2";
            // 
            // Rohstoffname3
            // 
            this.Rohstoffname3.DataPropertyName = "Rohstoffname3";
            this.Rohstoffname3.HeaderText = "Rohstoffname3";
            this.Rohstoffname3.Name = "Rohstoffname3";
            // 
            // Rohstoffmenge3
            // 
            this.Rohstoffmenge3.DataPropertyName = "Rohstoffmenge3";
            this.Rohstoffmenge3.HeaderText = "Rohstoffmenge3";
            this.Rohstoffmenge3.Name = "Rohstoffmenge3";
            // 
            // RohstoffEinheit3
            // 
            this.RohstoffEinheit3.DataPropertyName = "RohstoffEinheit3";
            this.RohstoffEinheit3.HeaderText = "RohstoffEinheit3";
            this.RohstoffEinheit3.Name = "RohstoffEinheit3";
            // 
            // rezeptIDDataGridViewTextBoxColumn
            // 
            this.rezeptIDDataGridViewTextBoxColumn.DataPropertyName = "RezeptID";
            this.rezeptIDDataGridViewTextBoxColumn.HeaderText = "RezeptID";
            this.rezeptIDDataGridViewTextBoxColumn.Name = "rezeptIDDataGridViewTextBoxColumn";
            // 
            // rezeptNameDataGridViewTextBoxColumn
            // 
            this.rezeptNameDataGridViewTextBoxColumn.DataPropertyName = "RezeptName";
            this.rezeptNameDataGridViewTextBoxColumn.HeaderText = "RezeptName";
            this.rezeptNameDataGridViewTextBoxColumn.Name = "rezeptNameDataGridViewTextBoxColumn";
            // 
            // rohstoffnameDataGridViewTextBoxColumn1
            // 
            this.rohstoffnameDataGridViewTextBoxColumn1.DataPropertyName = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn1.HeaderText = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn1.Name = "rohstoffnameDataGridViewTextBoxColumn1";
            // 
            // rohstoffmengeDataGridViewTextBoxColumn
            // 
            this.rohstoffmengeDataGridViewTextBoxColumn.DataPropertyName = "Rohstoffmenge";
            this.rohstoffmengeDataGridViewTextBoxColumn.HeaderText = "Rohstoffmenge";
            this.rohstoffmengeDataGridViewTextBoxColumn.Name = "rohstoffmengeDataGridViewTextBoxColumn";
            // 
            // rohstoffEinheitDataGridViewTextBoxColumn1
            // 
            this.rohstoffEinheitDataGridViewTextBoxColumn1.DataPropertyName = "RohstoffEinheit";
            this.rohstoffEinheitDataGridViewTextBoxColumn1.HeaderText = "RohstoffEinheit";
            this.rohstoffEinheitDataGridViewTextBoxColumn1.Name = "rohstoffEinheitDataGridViewTextBoxColumn1";
            // 
            // rohstoffname1DataGridViewTextBoxColumn
            // 
            this.rohstoffname1DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffname1";
            this.rohstoffname1DataGridViewTextBoxColumn.HeaderText = "Rohstoffname1";
            this.rohstoffname1DataGridViewTextBoxColumn.Name = "rohstoffname1DataGridViewTextBoxColumn";
            // 
            // rohstoffmenge1DataGridViewTextBoxColumn
            // 
            this.rohstoffmenge1DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffmenge1";
            this.rohstoffmenge1DataGridViewTextBoxColumn.HeaderText = "Rohstoffmenge1";
            this.rohstoffmenge1DataGridViewTextBoxColumn.Name = "rohstoffmenge1DataGridViewTextBoxColumn";
            // 
            // rohstoffEinheit1DataGridViewTextBoxColumn
            // 
            this.rohstoffEinheit1DataGridViewTextBoxColumn.DataPropertyName = "RohstoffEinheit1";
            this.rohstoffEinheit1DataGridViewTextBoxColumn.HeaderText = "RohstoffEinheit1";
            this.rohstoffEinheit1DataGridViewTextBoxColumn.Name = "rohstoffEinheit1DataGridViewTextBoxColumn";
            // 
            // rohstoffname2DataGridViewTextBoxColumn
            // 
            this.rohstoffname2DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffname2";
            this.rohstoffname2DataGridViewTextBoxColumn.HeaderText = "Rohstoffname2";
            this.rohstoffname2DataGridViewTextBoxColumn.Name = "rohstoffname2DataGridViewTextBoxColumn";
            // 
            // rohstoffmenge2DataGridViewTextBoxColumn
            // 
            this.rohstoffmenge2DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffmenge2";
            this.rohstoffmenge2DataGridViewTextBoxColumn.HeaderText = "Rohstoffmenge2";
            this.rohstoffmenge2DataGridViewTextBoxColumn.Name = "rohstoffmenge2DataGridViewTextBoxColumn";
            // 
            // rohstoffEinheit2DataGridViewTextBoxColumn
            // 
            this.rohstoffEinheit2DataGridViewTextBoxColumn.DataPropertyName = "RohstoffEinheit2";
            this.rohstoffEinheit2DataGridViewTextBoxColumn.HeaderText = "RohstoffEinheit2";
            this.rohstoffEinheit2DataGridViewTextBoxColumn.Name = "rohstoffEinheit2DataGridViewTextBoxColumn";
            // 
            // rohstoffname3DataGridViewTextBoxColumn
            // 
            this.rohstoffname3DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffname3";
            this.rohstoffname3DataGridViewTextBoxColumn.HeaderText = "Rohstoffname3";
            this.rohstoffname3DataGridViewTextBoxColumn.Name = "rohstoffname3DataGridViewTextBoxColumn";
            // 
            // rohstoffmenge3DataGridViewTextBoxColumn
            // 
            this.rohstoffmenge3DataGridViewTextBoxColumn.DataPropertyName = "Rohstoffmenge3";
            this.rohstoffmenge3DataGridViewTextBoxColumn.HeaderText = "Rohstoffmenge3";
            this.rohstoffmenge3DataGridViewTextBoxColumn.Name = "rohstoffmenge3DataGridViewTextBoxColumn";
            // 
            // rohstoffEinheit3DataGridViewTextBoxColumn
            // 
            this.rohstoffEinheit3DataGridViewTextBoxColumn.DataPropertyName = "RohstoffEinheit3";
            this.rohstoffEinheit3DataGridViewTextBoxColumn.HeaderText = "RohstoffEinheit3";
            this.rohstoffEinheit3DataGridViewTextBoxColumn.Name = "rohstoffEinheit3DataGridViewTextBoxColumn";
            // 
            // produktEnthaeltBindingSource
            // 
            this.produktEnthaeltBindingSource.DataMember = "ProduktEnthaelt";
            this.produktEnthaeltBindingSource.DataSource = this.baeckerei40DataSet4;
            // 
            // baeckerei40DataSet4
            // 
            this.baeckerei40DataSet4.DataSetName = "baeckerei40DataSet4";
            this.baeckerei40DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPageKomissionierung
            // 
            this.tabPageKomissionierung.Controls.Add(this.panelKom);
            this.tabPageKomissionierung.Controls.Add(this.Kom_speichern);
            this.tabPageKomissionierung.Controls.Add(this.Kom_bearb);
            this.tabPageKomissionierung.Controls.Add(this.dataGridView3);
            this.tabPageKomissionierung.Controls.Add(this.groupBox10);
            this.tabPageKomissionierung.Controls.Add(this.groupBox9);
            this.tabPageKomissionierung.Location = new System.Drawing.Point(4, 22);
            this.tabPageKomissionierung.Name = "tabPageKomissionierung";
            this.tabPageKomissionierung.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageKomissionierung.Size = new System.Drawing.Size(993, 691);
            this.tabPageKomissionierung.TabIndex = 3;
            this.tabPageKomissionierung.Text = "Komissionierung";
            this.tabPageKomissionierung.UseVisualStyleBackColor = true;
            // 
            // panelKom
            // 
            this.panelKom.Controls.Add(this.tb_BestellID);
            this.panelKom.Controls.Add(this.Kom_GPreis);
            this.panelKom.Controls.Add(this.label19);
            this.panelKom.Controls.Add(this.label20);
            this.panelKom.Location = new System.Drawing.Point(450, 493);
            this.panelKom.Name = "panelKom";
            this.panelKom.Size = new System.Drawing.Size(322, 76);
            this.panelKom.TabIndex = 8;
            // 
            // tb_BestellID
            // 
            this.tb_BestellID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bestellungenBindingSource2, "BestellID", true));
            this.tb_BestellID.Location = new System.Drawing.Point(23, 36);
            this.tb_BestellID.Name = "tb_BestellID";
            this.tb_BestellID.Size = new System.Drawing.Size(125, 20);
            this.tb_BestellID.TabIndex = 2;
            // 
            // bestellungenBindingSource2
            // 
            this.bestellungenBindingSource2.DataMember = "Bestellungen";
            this.bestellungenBindingSource2.DataSource = this.baeckerei40DataSet10;
            // 
            // baeckerei40DataSet10
            // 
            this.baeckerei40DataSet10.DataSetName = "baeckerei40DataSet10";
            this.baeckerei40DataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Kom_GPreis
            // 
            this.Kom_GPreis.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bestellungenBindingSource2, "Gesamtpreis (in €)", true));
            this.Kom_GPreis.Location = new System.Drawing.Point(168, 36);
            this.Kom_GPreis.Name = "Kom_GPreis";
            this.Kom_GPreis.Size = new System.Drawing.Size(134, 20);
            this.Kom_GPreis.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(23, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "BestellID";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(165, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Gesamtpreis (in Euro)";
            // 
            // Kom_speichern
            // 
            this.Kom_speichern.Location = new System.Drawing.Point(811, 502);
            this.Kom_speichern.Name = "Kom_speichern";
            this.Kom_speichern.Size = new System.Drawing.Size(111, 46);
            this.Kom_speichern.TabIndex = 7;
            this.Kom_speichern.Text = "Speichern";
            this.Kom_speichern.UseVisualStyleBackColor = true;
            this.Kom_speichern.Click += new System.EventHandler(this.Kom_speichern_Click);
            // 
            // Kom_bearb
            // 
            this.Kom_bearb.Location = new System.Drawing.Point(309, 502);
            this.Kom_bearb.Name = "Kom_bearb";
            this.Kom_bearb.Size = new System.Drawing.Size(114, 46);
            this.Kom_bearb.TabIndex = 6;
            this.Kom_bearb.Text = "Bearbeiten";
            this.Kom_bearb.UseVisualStyleBackColor = true;
            this.Kom_bearb.Click += new System.EventHandler(this.Kom_bearb_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bestellIDDataGridViewTextBoxColumn2,
            this.kundenIDDataGridViewTextBoxColumn2,
            this.abholdatumDataGridViewTextBoxColumn1,
            this.abholzeitDataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn1,
            this.checkbox});
            this.dataGridView3.DataSource = this.bestellungenBindingSource2;
            this.dataGridView3.Location = new System.Drawing.Point(309, 265);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(660, 216);
            this.dataGridView3.TabIndex = 1;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // bestellIDDataGridViewTextBoxColumn2
            // 
            this.bestellIDDataGridViewTextBoxColumn2.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn2.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn2.Name = "bestellIDDataGridViewTextBoxColumn2";
            // 
            // kundenIDDataGridViewTextBoxColumn2
            // 
            this.kundenIDDataGridViewTextBoxColumn2.DataPropertyName = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn2.HeaderText = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn2.Name = "kundenIDDataGridViewTextBoxColumn2";
            // 
            // abholdatumDataGridViewTextBoxColumn1
            // 
            this.abholdatumDataGridViewTextBoxColumn1.DataPropertyName = "Abholdatum";
            this.abholdatumDataGridViewTextBoxColumn1.HeaderText = "Abholdatum";
            this.abholdatumDataGridViewTextBoxColumn1.Name = "abholdatumDataGridViewTextBoxColumn1";
            // 
            // abholzeitDataGridViewTextBoxColumn1
            // 
            this.abholzeitDataGridViewTextBoxColumn1.DataPropertyName = "Abholzeit";
            this.abholzeitDataGridViewTextBoxColumn1.HeaderText = "Abholzeit";
            this.abholzeitDataGridViewTextBoxColumn1.Name = "abholzeitDataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Gesamtpreis (in €)";
            this.dataGridViewTextBoxColumn1.HeaderText = "Gesamtpreis (in €)";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // checkbox
            // 
            this.checkbox.HeaderText = "Bestellung abgeholt";
            this.checkbox.Name = "checkbox";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button_mult);
            this.groupBox10.Controls.Add(this.button_istgleich);
            this.groupBox10.Controls.Add(this.button_clear);
            this.groupBox10.Controls.Add(this.textBox_anzeige);
            this.groupBox10.Controls.Add(this.btn_minus);
            this.groupBox10.Controls.Add(this.button10);
            this.groupBox10.Controls.Add(this.button9);
            this.groupBox10.Controls.Add(this.button8);
            this.groupBox10.Controls.Add(this.button7);
            this.groupBox10.Controls.Add(this.button6);
            this.groupBox10.Controls.Add(this.button5);
            this.groupBox10.Controls.Add(this.button4);
            this.groupBox10.Controls.Add(this.button3);
            this.groupBox10.Controls.Add(this.button2);
            this.groupBox10.Controls.Add(this.button1);
            this.groupBox10.Controls.Add(this.plus);
            this.groupBox10.Location = new System.Drawing.Point(6, 265);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(296, 319);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "TASCHENRECHNER";
            // 
            // button_mult
            // 
            this.button_mult.Location = new System.Drawing.Point(193, 151);
            this.button_mult.Name = "button_mult";
            this.button_mult.Size = new System.Drawing.Size(41, 23);
            this.button_mult.TabIndex = 36;
            this.button_mult.Text = "x";
            this.button_mult.UseVisualStyleBackColor = true;
            this.button_mult.Click += new System.EventHandler(this.button_mult_Click_1);
            // 
            // button_istgleich
            // 
            this.button_istgleich.Location = new System.Drawing.Point(193, 189);
            this.button_istgleich.Name = "button_istgleich";
            this.button_istgleich.Size = new System.Drawing.Size(88, 23);
            this.button_istgleich.TabIndex = 33;
            this.button_istgleich.Text = "=";
            this.button_istgleich.UseVisualStyleBackColor = true;
            this.button_istgleich.Click += new System.EventHandler(this.button_istgleich_Click_1);
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(240, 151);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(41, 23);
            this.button_clear.TabIndex = 32;
            this.button_clear.Text = "C";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click_1);
            // 
            // textBox_anzeige
            // 
            this.textBox_anzeige.Location = new System.Drawing.Point(13, 68);
            this.textBox_anzeige.Name = "textBox_anzeige";
            this.textBox_anzeige.Size = new System.Drawing.Size(163, 20);
            this.textBox_anzeige.TabIndex = 31;
            // 
            // btn_minus
            // 
            this.btn_minus.Location = new System.Drawing.Point(240, 111);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(41, 23);
            this.btn_minus.TabIndex = 30;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click_1);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(72, 228);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(44, 23);
            this.button10.TabIndex = 29;
            this.button10.Text = "0";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(132, 189);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(44, 23);
            this.button9.TabIndex = 28;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(72, 189);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(44, 23);
            this.button8.TabIndex = 27;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(13, 189);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(44, 23);
            this.button7.TabIndex = 26;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(132, 151);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(44, 23);
            this.button6.TabIndex = 25;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(72, 151);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(44, 23);
            this.button5.TabIndex = 24;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(13, 151);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(44, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(132, 111);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(44, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(72, 111);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(44, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(193, 111);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(41, 23);
            this.plus.TabIndex = 19;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click_1);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dataGridViewPL);
            this.groupBox9.Controls.Add(this.dataGridView4);
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(981, 253);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Abholliste";
            // 
            // dataGridViewPL
            // 
            this.dataGridViewPL.AutoGenerateColumns = false;
            this.dataGridViewPL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.produktIDDataGridViewTextBoxColumn2,
            this.produktNameDataGridViewTextBoxColumn1,
            this.produktPreisDataGridViewTextBoxColumn1});
            this.dataGridViewPL.DataSource = this.produkteBindingSource1;
            this.dataGridViewPL.Location = new System.Drawing.Point(17, 20);
            this.dataGridViewPL.Name = "dataGridViewPL";
            this.dataGridViewPL.Size = new System.Drawing.Size(383, 216);
            this.dataGridViewPL.TabIndex = 0;
            // 
            // produktIDDataGridViewTextBoxColumn2
            // 
            this.produktIDDataGridViewTextBoxColumn2.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn2.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn2.Name = "produktIDDataGridViewTextBoxColumn2";
            // 
            // produktNameDataGridViewTextBoxColumn1
            // 
            this.produktNameDataGridViewTextBoxColumn1.DataPropertyName = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn1.HeaderText = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn1.Name = "produktNameDataGridViewTextBoxColumn1";
            // 
            // produktPreisDataGridViewTextBoxColumn1
            // 
            this.produktPreisDataGridViewTextBoxColumn1.DataPropertyName = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn1.HeaderText = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn1.Name = "produktPreisDataGridViewTextBoxColumn1";
            // 
            // produkteBindingSource1
            // 
            this.produkteBindingSource1.DataMember = "Produkte";
            this.produkteBindingSource1.DataSource = this.baeckerei40DataSet6;
            // 
            // baeckerei40DataSet6
            // 
            this.baeckerei40DataSet6.DataSetName = "baeckerei40DataSet6";
            this.baeckerei40DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn1,
            this.bestellIDDataGridViewTextBoxColumn3,
            this.produktIDDataGridViewTextBoxColumn3,
            this.bestellMengeDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.bestellungEnthaeltBindingSource1;
            this.dataGridView4.Location = new System.Drawing.Point(421, 19);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(542, 217);
            this.dataGridView4.TabIndex = 0;
            // 
            // bestellungEnthaeltIDDataGridViewTextBoxColumn1
            // 
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn1.DataPropertyName = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn1.HeaderText = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn1.Name = "bestellungEnthaeltIDDataGridViewTextBoxColumn1";
            // 
            // bestellIDDataGridViewTextBoxColumn3
            // 
            this.bestellIDDataGridViewTextBoxColumn3.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn3.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn3.Name = "bestellIDDataGridViewTextBoxColumn3";
            // 
            // produktIDDataGridViewTextBoxColumn3
            // 
            this.produktIDDataGridViewTextBoxColumn3.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn3.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn3.Name = "produktIDDataGridViewTextBoxColumn3";
            // 
            // bestellMengeDataGridViewTextBoxColumn1
            // 
            this.bestellMengeDataGridViewTextBoxColumn1.DataPropertyName = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn1.HeaderText = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn1.Name = "bestellMengeDataGridViewTextBoxColumn1";
            // 
            // bestellungEnthaeltBindingSource1
            // 
            this.bestellungEnthaeltBindingSource1.DataMember = "BestellungEnthaelt";
            this.bestellungEnthaeltBindingSource1.DataSource = this.baeckerei40DataSet9;
            // 
            // baeckerei40DataSet9
            // 
            this.baeckerei40DataSet9.DataSetName = "baeckerei40DataSet9";
            this.baeckerei40DataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bestellungenBindingSource1
            // 
            this.bestellungenBindingSource1.DataMember = "Bestellungen";
            this.bestellungenBindingSource1.DataSource = this.baeckerei40DataSet8;
            // 
            // baeckerei40DataSet8
            // 
            this.baeckerei40DataSet8.DataSetName = "baeckerei40DataSet8";
            this.baeckerei40DataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPageLager
            // 
            this.tabPageLager.Controls.Add(this.RSpeichern);
            this.tabPageLager.Controls.Add(this.panel);
            this.tabPageLager.Controls.Add(this.groupBox7);
            this.tabPageLager.Controls.Add(this.RHinzufügen);
            this.tabPageLager.Controls.Add(this.RBearbeiten);
            this.tabPageLager.Controls.Add(this.RAbbrechen);
            this.tabPageLager.Location = new System.Drawing.Point(4, 22);
            this.tabPageLager.Name = "tabPageLager";
            this.tabPageLager.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLager.Size = new System.Drawing.Size(993, 691);
            this.tabPageLager.TabIndex = 2;
            this.tabPageLager.Text = "Lager";
            this.tabPageLager.UseVisualStyleBackColor = true;
            // 
            // RSpeichern
            // 
            this.RSpeichern.Location = new System.Drawing.Point(779, 544);
            this.RSpeichern.Name = "RSpeichern";
            this.RSpeichern.Size = new System.Drawing.Size(97, 55);
            this.RSpeichern.TabIndex = 13;
            this.RSpeichern.Text = "Speichern";
            this.RSpeichern.UseVisualStyleBackColor = true;
            this.RSpeichern.Click += new System.EventHandler(this.RSpeichern_Click);
            // 
            // panel
            // 
            this.panel.Controls.Add(this.labeli);
            this.panel.Controls.Add(this.RID);
            this.panel.Controls.Add(this.RPreis);
            this.panel.Controls.Add(this.REinheit);
            this.panel.Controls.Add(this.LMenge);
            this.panel.Controls.Add(this.RName);
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label1);
            this.panel.Location = new System.Drawing.Point(9, 319);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(720, 310);
            this.panel.TabIndex = 1;
            this.panel.TabStop = false;
            this.panel.Text = "Bestände buchen";
            // 
            // labeli
            // 
            this.labeli.AutoSize = true;
            this.labeli.Location = new System.Drawing.Point(26, 16);
            this.labeli.Name = "labeli";
            this.labeli.Size = new System.Drawing.Size(58, 13);
            this.labeli.TabIndex = 12;
            this.labeli.Text = "RohstoffID";
            // 
            // RID
            // 
            this.RID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "RohstoffID", true));
            this.RID.Location = new System.Drawing.Point(29, 38);
            this.RID.Name = "RID";
            this.RID.Size = new System.Drawing.Size(245, 20);
            this.RID.TabIndex = 11;
            // 
            // rohstoffeBindingSource
            // 
            this.rohstoffeBindingSource.DataMember = "Rohstoffe";
            this.rohstoffeBindingSource.DataSource = this.baeckerei40DataSet1;
            // 
            // baeckerei40DataSet1
            // 
            this.baeckerei40DataSet1.DataSetName = "baeckerei40DataSet1";
            this.baeckerei40DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // RPreis
            // 
            this.RPreis.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "RohstoffPreis", true));
            this.RPreis.Location = new System.Drawing.Point(29, 206);
            this.RPreis.Name = "RPreis";
            this.RPreis.Size = new System.Drawing.Size(245, 20);
            this.RPreis.TabIndex = 7;
            // 
            // REinheit
            // 
            this.REinheit.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Rohstoffeinheit", true));
            this.REinheit.Location = new System.Drawing.Point(29, 152);
            this.REinheit.Name = "REinheit";
            this.REinheit.Size = new System.Drawing.Size(245, 20);
            this.REinheit.TabIndex = 6;
            // 
            // LMenge
            // 
            this.LMenge.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Lagermenge", true));
            this.LMenge.Location = new System.Drawing.Point(29, 262);
            this.LMenge.Name = "LMenge";
            this.LMenge.Size = new System.Drawing.Size(245, 20);
            this.LMenge.TabIndex = 5;
            // 
            // RName
            // 
            this.RName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Rohstoffname", true));
            this.RName.Location = new System.Drawing.Point(29, 89);
            this.RName.Name = "RName";
            this.RName.Size = new System.Drawing.Size(245, 20);
            this.RName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Lagermenge";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Rohstoffpreis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Rohstoffeinheit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rohstoffname";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dataGridViewLager);
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(964, 307);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lagerliste";
            // 
            // dataGridViewLager
            // 
            this.dataGridViewLager.AutoGenerateColumns = false;
            this.dataGridViewLager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rohstoffIDDataGridViewTextBoxColumn,
            this.rohstoffnameDataGridViewTextBoxColumn,
            this.rohstoffeinheitDataGridViewTextBoxColumn,
            this.rohstoffPreisDataGridViewTextBoxColumn,
            this.lagermengeDataGridViewTextBoxColumn});
            this.dataGridViewLager.DataSource = this.rohstoffeBindingSource;
            this.dataGridViewLager.Location = new System.Drawing.Point(32, 31);
            this.dataGridViewLager.Name = "dataGridViewLager";
            this.dataGridViewLager.Size = new System.Drawing.Size(886, 231);
            this.dataGridViewLager.TabIndex = 0;
            this.dataGridViewLager.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLager_CellContentClick);
            this.dataGridViewLager.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridViewLager_KeyDown);
            // 
            // rohstoffIDDataGridViewTextBoxColumn
            // 
            this.rohstoffIDDataGridViewTextBoxColumn.DataPropertyName = "RohstoffID";
            this.rohstoffIDDataGridViewTextBoxColumn.HeaderText = "RohstoffID";
            this.rohstoffIDDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.rohstoffIDDataGridViewTextBoxColumn.Name = "rohstoffIDDataGridViewTextBoxColumn";
            // 
            // rohstoffnameDataGridViewTextBoxColumn
            // 
            this.rohstoffnameDataGridViewTextBoxColumn.DataPropertyName = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn.HeaderText = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn.Name = "rohstoffnameDataGridViewTextBoxColumn";
            // 
            // rohstoffeinheitDataGridViewTextBoxColumn
            // 
            this.rohstoffeinheitDataGridViewTextBoxColumn.DataPropertyName = "Rohstoffeinheit";
            this.rohstoffeinheitDataGridViewTextBoxColumn.HeaderText = "Rohstoffeinheit";
            this.rohstoffeinheitDataGridViewTextBoxColumn.Name = "rohstoffeinheitDataGridViewTextBoxColumn";
            // 
            // rohstoffPreisDataGridViewTextBoxColumn
            // 
            this.rohstoffPreisDataGridViewTextBoxColumn.DataPropertyName = "RohstoffPreis";
            this.rohstoffPreisDataGridViewTextBoxColumn.HeaderText = "RohstoffPreis";
            this.rohstoffPreisDataGridViewTextBoxColumn.Name = "rohstoffPreisDataGridViewTextBoxColumn";
            // 
            // lagermengeDataGridViewTextBoxColumn
            // 
            this.lagermengeDataGridViewTextBoxColumn.DataPropertyName = "Lagermenge";
            this.lagermengeDataGridViewTextBoxColumn.HeaderText = "Lagermenge";
            this.lagermengeDataGridViewTextBoxColumn.Name = "lagermengeDataGridViewTextBoxColumn";
            // 
            // RHinzufügen
            // 
            this.RHinzufügen.Location = new System.Drawing.Point(779, 356);
            this.RHinzufügen.Name = "RHinzufügen";
            this.RHinzufügen.Size = new System.Drawing.Size(97, 49);
            this.RHinzufügen.TabIndex = 8;
            this.RHinzufügen.Text = "Hinzufügen";
            this.RHinzufügen.UseVisualStyleBackColor = true;
            this.RHinzufügen.Click += new System.EventHandler(this.RHinzufügen_Click);
            // 
            // RBearbeiten
            // 
            this.RBearbeiten.Location = new System.Drawing.Point(779, 417);
            this.RBearbeiten.Name = "RBearbeiten";
            this.RBearbeiten.Size = new System.Drawing.Size(97, 51);
            this.RBearbeiten.TabIndex = 10;
            this.RBearbeiten.Text = "Bearbeiten";
            this.RBearbeiten.UseVisualStyleBackColor = true;
            this.RBearbeiten.Click += new System.EventHandler(this.RBearbeiten_Click);
            // 
            // RAbbrechen
            // 
            this.RAbbrechen.Location = new System.Drawing.Point(779, 476);
            this.RAbbrechen.Name = "RAbbrechen";
            this.RAbbrechen.Size = new System.Drawing.Size(97, 48);
            this.RAbbrechen.TabIndex = 9;
            this.RAbbrechen.Text = "Abbrechen";
            this.RAbbrechen.UseVisualStyleBackColor = true;
            this.RAbbrechen.Click += new System.EventHandler(this.RAbbrechen_Click);
            // 
            // tabPageProduktion
            // 
            this.tabPageProduktion.Controls.Add(this.groupBox6);
            this.tabPageProduktion.Controls.Add(this.groupBox5);
            this.tabPageProduktion.Controls.Add(this.buttonProduktionSpeichern);
            this.tabPageProduktion.Location = new System.Drawing.Point(4, 22);
            this.tabPageProduktion.Name = "tabPageProduktion";
            this.tabPageProduktion.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProduktion.Size = new System.Drawing.Size(993, 691);
            this.tabPageProduktion.TabIndex = 1;
            this.tabPageProduktion.Text = "Produktion";
            this.tabPageProduktion.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(3, 319);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(967, 335);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Details";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridViewProduktionsliste);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(964, 307);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Produktionsliste";
            // 
            // dataGridViewProduktionsliste
            // 
            this.dataGridViewProduktionsliste.AllowUserToAddRows = false;
            this.dataGridViewProduktionsliste.AutoGenerateColumns = false;
            this.dataGridViewProduktionsliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduktionsliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn,
            this.bestellIDDataGridViewTextBoxColumn1,
            this.produktIDDataGridViewTextBoxColumn1,
            this.bestellMengeDataGridViewTextBoxColumn,
            this.produziertDataGridViewCheckBoxColumn});
            this.dataGridViewProduktionsliste.DataSource = this.bestellungEnthaeltBindingSource;
            this.dataGridViewProduktionsliste.Location = new System.Drawing.Point(6, 19);
            this.dataGridViewProduktionsliste.Name = "dataGridViewProduktionsliste";
            this.dataGridViewProduktionsliste.Size = new System.Drawing.Size(958, 282);
            this.dataGridViewProduktionsliste.TabIndex = 0;
            // 
            // bestellungEnthaeltIDDataGridViewTextBoxColumn
            // 
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.DataPropertyName = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.HeaderText = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.Name = "bestellungEnthaeltIDDataGridViewTextBoxColumn";
            // 
            // bestellIDDataGridViewTextBoxColumn1
            // 
            this.bestellIDDataGridViewTextBoxColumn1.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn1.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn1.Name = "bestellIDDataGridViewTextBoxColumn1";
            // 
            // produktIDDataGridViewTextBoxColumn1
            // 
            this.produktIDDataGridViewTextBoxColumn1.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn1.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn1.Name = "produktIDDataGridViewTextBoxColumn1";
            // 
            // bestellMengeDataGridViewTextBoxColumn
            // 
            this.bestellMengeDataGridViewTextBoxColumn.DataPropertyName = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn.HeaderText = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn.Name = "bestellMengeDataGridViewTextBoxColumn";
            // 
            // produziertDataGridViewCheckBoxColumn
            // 
            this.produziertDataGridViewCheckBoxColumn.DataPropertyName = "Produziert";
            this.produziertDataGridViewCheckBoxColumn.HeaderText = "Produziert";
            this.produziertDataGridViewCheckBoxColumn.Name = "produziertDataGridViewCheckBoxColumn";
            // 
            // bestellungEnthaeltBindingSource
            // 
            this.bestellungEnthaeltBindingSource.DataMember = "BestellungEnthaelt";
            this.bestellungEnthaeltBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // baeckerei40DataSet
            // 
            this.baeckerei40DataSet.DataSetName = "baeckerei40DataSet";
            this.baeckerei40DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonProduktionSpeichern
            // 
            this.buttonProduktionSpeichern.Location = new System.Drawing.Point(3, 660);
            this.buttonProduktionSpeichern.Name = "buttonProduktionSpeichern";
            this.buttonProduktionSpeichern.Size = new System.Drawing.Size(162, 23);
            this.buttonProduktionSpeichern.TabIndex = 0;
            this.buttonProduktionSpeichern.Text = "Produktion Speichern";
            this.buttonProduktionSpeichern.UseVisualStyleBackColor = true;
            this.buttonProduktionSpeichern.Click += new System.EventHandler(this.buttonProduktionSpeichern_Click);
            // 
            // tabPageBestellung
            // 
            this.tabPageBestellung.AutoScroll = true;
            this.tabPageBestellung.Controls.Add(this.buttonWarenkorbHinzufuegen);
            this.tabPageBestellung.Controls.Add(this.groupBox4);
            this.tabPageBestellung.Controls.Add(this.groupBox3);
            this.tabPageBestellung.Controls.Add(this.groupBox2);
            this.tabPageBestellung.Controls.Add(this.groupBox1);
            this.tabPageBestellung.Location = new System.Drawing.Point(4, 22);
            this.tabPageBestellung.Name = "tabPageBestellung";
            this.tabPageBestellung.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBestellung.Size = new System.Drawing.Size(993, 691);
            this.tabPageBestellung.TabIndex = 0;
            this.tabPageBestellung.Text = "Bestellung";
            this.tabPageBestellung.UseVisualStyleBackColor = true;
            // 
            // buttonWarenkorbHinzufuegen
            // 
            this.buttonWarenkorbHinzufuegen.Location = new System.Drawing.Point(541, 293);
            this.buttonWarenkorbHinzufuegen.Name = "buttonWarenkorbHinzufuegen";
            this.buttonWarenkorbHinzufuegen.Size = new System.Drawing.Size(58, 23);
            this.buttonWarenkorbHinzufuegen.TabIndex = 4;
            this.buttonWarenkorbHinzufuegen.Text = "<<";
            this.buttonWarenkorbHinzufuegen.UseVisualStyleBackColor = true;
            this.buttonWarenkorbHinzufuegen.Click += new System.EventHandler(this.buttonWarenkorbHinzufuegen_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridViewBestellliste);
            this.groupBox4.Controls.Add(this.buttonBestelllisteSpeichern);
            this.groupBox4.Location = new System.Drawing.Point(6, 451);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(593, 234);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bestellliste";
            // 
            // dataGridViewBestellliste
            // 
            this.dataGridViewBestellliste.AllowUserToOrderColumns = true;
            this.dataGridViewBestellliste.AutoGenerateColumns = false;
            this.dataGridViewBestellliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBestellliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.KundenID,
            this.Abholdatum,
            this.Abholzeit,
            this.bestellIDDataGridViewTextBoxColumn});
            this.dataGridViewBestellliste.DataSource = this.bestellungenBindingSource;
            this.dataGridViewBestellliste.Location = new System.Drawing.Point(10, 19);
            this.dataGridViewBestellliste.Name = "dataGridViewBestellliste";
            this.dataGridViewBestellliste.Size = new System.Drawing.Size(519, 168);
            this.dataGridViewBestellliste.TabIndex = 2;
            // 
            // KundenID
            // 
            this.KundenID.DataPropertyName = "KundenID";
            this.KundenID.HeaderText = "KundenID";
            this.KundenID.Name = "KundenID";
            // 
            // Abholdatum
            // 
            this.Abholdatum.DataPropertyName = "Abholdatum";
            this.Abholdatum.HeaderText = "Abholdatum";
            this.Abholdatum.Name = "Abholdatum";
            // 
            // Abholzeit
            // 
            this.Abholzeit.DataPropertyName = "Abholzeit";
            this.Abholzeit.HeaderText = "Abholzeit";
            this.Abholzeit.Name = "Abholzeit";
            // 
            // bestellIDDataGridViewTextBoxColumn
            // 
            this.bestellIDDataGridViewTextBoxColumn.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn.Name = "bestellIDDataGridViewTextBoxColumn";
            // 
            // bestellungenBindingSource
            // 
            this.bestellungenBindingSource.DataMember = "Bestellungen";
            this.bestellungenBindingSource.DataSource = this.baeckerei40DataSet;
            this.bestellungenBindingSource.CurrentChanged += new System.EventHandler(this.bestellungenBindingSource_CurrentChanged);
            // 
            // buttonBestelllisteSpeichern
            // 
            this.buttonBestelllisteSpeichern.Location = new System.Drawing.Point(159, 197);
            this.buttonBestelllisteSpeichern.Name = "buttonBestelllisteSpeichern";
            this.buttonBestelllisteSpeichern.Size = new System.Drawing.Size(217, 23);
            this.buttonBestelllisteSpeichern.TabIndex = 7;
            this.buttonBestelllisteSpeichern.Text = "Änderungen an Bestellliste speichern";
            this.buttonBestelllisteSpeichern.Click += new System.EventHandler(this.buttonBestelllisteSpeichern_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonBestellen);
            this.groupBox3.Controls.Add(this.labelGesamtpreis);
            this.groupBox3.Controls.Add(this.buttonWarenkorbEntfernen);
            this.groupBox3.Controls.Add(this.labelWarenkorb);
            this.groupBox3.Controls.Add(this.dateTimePickerAbholzeit);
            this.groupBox3.Controls.Add(this.labelAbholzeit);
            this.groupBox3.Controls.Add(this.listBoxWarenkorb);
            this.groupBox3.Controls.Add(this.labelAbholdatum);
            this.groupBox3.Controls.Add(this.dateTimePickerAbholdatum);
            this.groupBox3.Location = new System.Drawing.Point(7, 185);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(592, 260);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Warenkorb";
            // 
            // buttonBestellen
            // 
            this.buttonBestellen.Location = new System.Drawing.Point(81, 179);
            this.buttonBestellen.Name = "buttonBestellen";
            this.buttonBestellen.Size = new System.Drawing.Size(183, 63);
            this.buttonBestellen.TabIndex = 27;
            this.buttonBestellen.Text = "Bestellen";
            this.buttonBestellen.Click += new System.EventHandler(this.buttonBestellen_Click);
            // 
            // labelGesamtpreis
            // 
            this.labelGesamtpreis.AutoSize = true;
            this.labelGesamtpreis.Location = new System.Drawing.Point(100, 146);
            this.labelGesamtpreis.Name = "labelGesamtpreis";
            this.labelGesamtpreis.Size = new System.Drawing.Size(69, 13);
            this.labelGesamtpreis.TabIndex = 26;
            this.labelGesamtpreis.Text = "Gesamt-Preis";
            // 
            // buttonWarenkorbEntfernen
            // 
            this.buttonWarenkorbEntfernen.Location = new System.Drawing.Point(534, 136);
            this.buttonWarenkorbEntfernen.Name = "buttonWarenkorbEntfernen";
            this.buttonWarenkorbEntfernen.Size = new System.Drawing.Size(58, 23);
            this.buttonWarenkorbEntfernen.TabIndex = 5;
            this.buttonWarenkorbEntfernen.Text = ">>";
            this.buttonWarenkorbEntfernen.UseVisualStyleBackColor = true;
            this.buttonWarenkorbEntfernen.Click += new System.EventHandler(this.buttonWarenkorbEntfernen_Click);
            // 
            // labelWarenkorb
            // 
            this.labelWarenkorb.AutoSize = true;
            this.labelWarenkorb.Location = new System.Drawing.Point(338, 16);
            this.labelWarenkorb.Name = "labelWarenkorb";
            this.labelWarenkorb.Size = new System.Drawing.Size(127, 13);
            this.labelWarenkorb.TabIndex = 25;
            this.labelWarenkorb.Text = "ProduktID - Produktname";
            // 
            // dateTimePickerAbholzeit
            // 
            this.dateTimePickerAbholzeit.CustomFormat = "";
            this.dateTimePickerAbholzeit.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerAbholzeit.Location = new System.Drawing.Point(103, 100);
            this.dateTimePickerAbholzeit.Name = "dateTimePickerAbholzeit";
            this.dateTimePickerAbholzeit.Size = new System.Drawing.Size(161, 20);
            this.dateTimePickerAbholzeit.TabIndex = 23;
            // 
            // labelAbholzeit
            // 
            this.labelAbholzeit.AutoSize = true;
            this.labelAbholzeit.Location = new System.Drawing.Point(42, 106);
            this.labelAbholzeit.Name = "labelAbholzeit";
            this.labelAbholzeit.Size = new System.Drawing.Size(50, 13);
            this.labelAbholzeit.TabIndex = 22;
            this.labelAbholzeit.Text = "Abholzeit";
            // 
            // listBoxWarenkorb
            // 
            this.listBoxWarenkorb.FormattingEnabled = true;
            this.listBoxWarenkorb.Location = new System.Drawing.Point(287, 39);
            this.listBoxWarenkorb.Name = "listBoxWarenkorb";
            this.listBoxWarenkorb.Size = new System.Drawing.Size(241, 212);
            this.listBoxWarenkorb.TabIndex = 21;
            // 
            // labelAbholdatum
            // 
            this.labelAbholdatum.AutoSize = true;
            this.labelAbholdatum.Location = new System.Drawing.Point(34, 78);
            this.labelAbholdatum.Name = "labelAbholdatum";
            this.labelAbholdatum.Size = new System.Drawing.Size(63, 13);
            this.labelAbholdatum.TabIndex = 20;
            this.labelAbholdatum.Text = "Abholdatum";
            // 
            // dateTimePickerAbholdatum
            // 
            this.dateTimePickerAbholdatum.CustomFormat = "";
            this.dateTimePickerAbholdatum.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerAbholdatum.Location = new System.Drawing.Point(103, 71);
            this.dateTimePickerAbholdatum.Name = "dateTimePickerAbholdatum";
            this.dateTimePickerAbholdatum.Size = new System.Drawing.Size(161, 20);
            this.dateTimePickerAbholdatum.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonAenderungProduktliste);
            this.groupBox2.Controls.Add(this.dataGridViewProduktliste);
            this.groupBox2.Location = new System.Drawing.Point(605, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 500);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Produktliste";
            // 
            // buttonAenderungProduktliste
            // 
            this.buttonAenderungProduktliste.Location = new System.Drawing.Point(101, 459);
            this.buttonAenderungProduktliste.Name = "buttonAenderungProduktliste";
            this.buttonAenderungProduktliste.Size = new System.Drawing.Size(191, 27);
            this.buttonAenderungProduktliste.TabIndex = 28;
            this.buttonAenderungProduktliste.Text = "Änderung an Produktliste speichern";
            this.buttonAenderungProduktliste.Click += new System.EventHandler(this.buttonAenderungProduktliste_Click);
            // 
            // dataGridViewProduktliste
            // 
            this.dataGridViewProduktliste.AllowUserToOrderColumns = true;
            this.dataGridViewProduktliste.AutoGenerateColumns = false;
            this.dataGridViewProduktliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduktliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.produktIDDataGridViewTextBoxColumn,
            this.produktNameDataGridViewTextBoxColumn,
            this.produktPreisDataGridViewTextBoxColumn});
            this.dataGridViewProduktliste.DataSource = this.produkteBindingSource;
            this.dataGridViewProduktliste.Location = new System.Drawing.Point(5, 19);
            this.dataGridViewProduktliste.Name = "dataGridViewProduktliste";
            this.dataGridViewProduktliste.Size = new System.Drawing.Size(362, 434);
            this.dataGridViewProduktliste.TabIndex = 1;
            this.dataGridViewProduktliste.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewdataGridViewProduktliste_CellContentDoubleClick);
            // 
            // produktIDDataGridViewTextBoxColumn
            // 
            this.produktIDDataGridViewTextBoxColumn.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn.Name = "produktIDDataGridViewTextBoxColumn";
            // 
            // produktNameDataGridViewTextBoxColumn
            // 
            this.produktNameDataGridViewTextBoxColumn.DataPropertyName = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn.HeaderText = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn.Name = "produktNameDataGridViewTextBoxColumn";
            // 
            // produktPreisDataGridViewTextBoxColumn
            // 
            this.produktPreisDataGridViewTextBoxColumn.DataPropertyName = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn.HeaderText = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn.Name = "produktPreisDataGridViewTextBoxColumn";
            // 
            // produkteBindingSource
            // 
            this.produkteBindingSource.DataMember = "Produkte";
            this.produkteBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonKundeHinzufügen);
            this.groupBox1.Controls.Add(this.buttonBearbeiten);
            this.groupBox1.Controls.Add(this.groupBox18);
            this.groupBox1.Controls.Add(this.textBoxKundennummer);
            this.groupBox1.Controls.Add(this.labelKundennummer);
            this.groupBox1.Controls.Add(this.textBoxTelefonnummer);
            this.groupBox1.Controls.Add(this.labelTelefonnummer);
            this.groupBox1.Controls.Add(this.textBoxNachname);
            this.groupBox1.Controls.Add(this.labelNachname);
            this.groupBox1.Controls.Add(this.textBoxVorname);
            this.groupBox1.Controls.Add(this.labelVorname);
            this.groupBox1.Location = new System.Drawing.Point(7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(971, 175);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kunde";
            // 
            // buttonKundeHinzufügen
            // 
            this.buttonKundeHinzufügen.Location = new System.Drawing.Point(103, 123);
            this.buttonKundeHinzufügen.Name = "buttonKundeHinzufügen";
            this.buttonKundeHinzufügen.Size = new System.Drawing.Size(80, 23);
            this.buttonKundeHinzufügen.TabIndex = 15;
            this.buttonKundeHinzufügen.Text = "hinzufügen";
            this.buttonKundeHinzufügen.UseVisualStyleBackColor = true;
            this.buttonKundeHinzufügen.Click += new System.EventHandler(this.buttonKundeHinzufuegen_Click);
            // 
            // buttonBearbeiten
            // 
            this.buttonBearbeiten.Location = new System.Drawing.Point(184, 123);
            this.buttonBearbeiten.Name = "buttonBearbeiten";
            this.buttonBearbeiten.Size = new System.Drawing.Size(80, 23);
            this.buttonBearbeiten.TabIndex = 13;
            this.buttonBearbeiten.Text = "bearbeiten";
            this.buttonBearbeiten.UseVisualStyleBackColor = true;
            this.buttonBearbeiten.Click += new System.EventHandler(this.buttonKundeBearbeiten_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.dataGridKundenliste);
            this.groupBox18.Location = new System.Drawing.Point(279, 17);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(692, 158);
            this.groupBox18.TabIndex = 12;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Kundenliste";
            // 
            // dataGridKundenliste
            // 
            this.dataGridKundenliste.AllowUserToOrderColumns = true;
            this.dataGridKundenliste.AutoGenerateColumns = false;
            this.dataGridKundenliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridKundenliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kundenIDDataGridViewTextBoxColumn,
            this.vornameDataGridViewTextBoxColumn,
            this.nachnameDataGridViewTextBoxColumn,
            this.telefonnummerDataGridViewTextBoxColumn,
            this.eMailDataGridViewTextBoxColumn,
            this.adresseDataGridViewTextBoxColumn,
            this.pLZDataGridViewTextBoxColumn,
            this.ortDataGridViewTextBoxColumn});
            this.dataGridKundenliste.DataSource = this.kundenBindingSource;
            this.dataGridKundenliste.Location = new System.Drawing.Point(8, 19);
            this.dataGridKundenliste.Name = "dataGridKundenliste";
            this.dataGridKundenliste.Size = new System.Drawing.Size(678, 119);
            this.dataGridKundenliste.TabIndex = 0;
            this.dataGridKundenliste.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridKundenliste_CellDoubleClick);
            // 
            // kundenIDDataGridViewTextBoxColumn
            // 
            this.kundenIDDataGridViewTextBoxColumn.DataPropertyName = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn.HeaderText = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn.Name = "kundenIDDataGridViewTextBoxColumn";
            // 
            // vornameDataGridViewTextBoxColumn
            // 
            this.vornameDataGridViewTextBoxColumn.DataPropertyName = "Vorname";
            this.vornameDataGridViewTextBoxColumn.HeaderText = "Vorname";
            this.vornameDataGridViewTextBoxColumn.Name = "vornameDataGridViewTextBoxColumn";
            // 
            // nachnameDataGridViewTextBoxColumn
            // 
            this.nachnameDataGridViewTextBoxColumn.DataPropertyName = "Nachname";
            this.nachnameDataGridViewTextBoxColumn.HeaderText = "Nachname";
            this.nachnameDataGridViewTextBoxColumn.Name = "nachnameDataGridViewTextBoxColumn";
            // 
            // telefonnummerDataGridViewTextBoxColumn
            // 
            this.telefonnummerDataGridViewTextBoxColumn.DataPropertyName = "Telefonnummer";
            this.telefonnummerDataGridViewTextBoxColumn.HeaderText = "Telefonnummer";
            this.telefonnummerDataGridViewTextBoxColumn.Name = "telefonnummerDataGridViewTextBoxColumn";
            // 
            // eMailDataGridViewTextBoxColumn
            // 
            this.eMailDataGridViewTextBoxColumn.DataPropertyName = "EMail";
            this.eMailDataGridViewTextBoxColumn.HeaderText = "EMail";
            this.eMailDataGridViewTextBoxColumn.Name = "eMailDataGridViewTextBoxColumn";
            // 
            // adresseDataGridViewTextBoxColumn
            // 
            this.adresseDataGridViewTextBoxColumn.DataPropertyName = "Adresse";
            this.adresseDataGridViewTextBoxColumn.HeaderText = "Adresse";
            this.adresseDataGridViewTextBoxColumn.Name = "adresseDataGridViewTextBoxColumn";
            // 
            // pLZDataGridViewTextBoxColumn
            // 
            this.pLZDataGridViewTextBoxColumn.DataPropertyName = "PLZ";
            this.pLZDataGridViewTextBoxColumn.HeaderText = "PLZ";
            this.pLZDataGridViewTextBoxColumn.Name = "pLZDataGridViewTextBoxColumn";
            // 
            // ortDataGridViewTextBoxColumn
            // 
            this.ortDataGridViewTextBoxColumn.DataPropertyName = "Ort";
            this.ortDataGridViewTextBoxColumn.HeaderText = "Ort";
            this.ortDataGridViewTextBoxColumn.Name = "ortDataGridViewTextBoxColumn";
            // 
            // kundenBindingSource
            // 
            this.kundenBindingSource.DataMember = "Kunden";
            this.kundenBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // textBoxKundennummer
            // 
            this.textBoxKundennummer.Location = new System.Drawing.Point(103, 19);
            this.textBoxKundennummer.Name = "textBoxKundennummer";
            this.textBoxKundennummer.ReadOnly = true;
            this.textBoxKundennummer.Size = new System.Drawing.Size(161, 20);
            this.textBoxKundennummer.TabIndex = 11;
            // 
            // labelKundennummer
            // 
            this.labelKundennummer.AutoSize = true;
            this.labelKundennummer.Location = new System.Drawing.Point(42, 22);
            this.labelKundennummer.Name = "labelKundennummer";
            this.labelKundennummer.Size = new System.Drawing.Size(55, 13);
            this.labelKundennummer.TabIndex = 10;
            this.labelKundennummer.Text = "KundenID";
            // 
            // textBoxTelefonnummer
            // 
            this.textBoxTelefonnummer.Location = new System.Drawing.Point(103, 97);
            this.textBoxTelefonnummer.Name = "textBoxTelefonnummer";
            this.textBoxTelefonnummer.Size = new System.Drawing.Size(161, 20);
            this.textBoxTelefonnummer.TabIndex = 9;
            // 
            // labelTelefonnummer
            // 
            this.labelTelefonnummer.AutoSize = true;
            this.labelTelefonnummer.Location = new System.Drawing.Point(17, 100);
            this.labelTelefonnummer.Name = "labelTelefonnummer";
            this.labelTelefonnummer.Size = new System.Drawing.Size(80, 13);
            this.labelTelefonnummer.TabIndex = 8;
            this.labelTelefonnummer.Text = "Telefonnummer";
            // 
            // textBoxNachname
            // 
            this.textBoxNachname.Location = new System.Drawing.Point(103, 71);
            this.textBoxNachname.Name = "textBoxNachname";
            this.textBoxNachname.Size = new System.Drawing.Size(161, 20);
            this.textBoxNachname.TabIndex = 3;
            // 
            // labelNachname
            // 
            this.labelNachname.AutoSize = true;
            this.labelNachname.Location = new System.Drawing.Point(42, 74);
            this.labelNachname.Name = "labelNachname";
            this.labelNachname.Size = new System.Drawing.Size(59, 13);
            this.labelNachname.TabIndex = 2;
            this.labelNachname.Text = "Nachname";
            // 
            // textBoxVorname
            // 
            this.textBoxVorname.Location = new System.Drawing.Point(103, 45);
            this.textBoxVorname.Name = "textBoxVorname";
            this.textBoxVorname.Size = new System.Drawing.Size(161, 20);
            this.textBoxVorname.TabIndex = 1;
            // 
            // labelVorname
            // 
            this.labelVorname.AutoSize = true;
            this.labelVorname.Location = new System.Drawing.Point(48, 48);
            this.labelVorname.Name = "labelVorname";
            this.labelVorname.Size = new System.Drawing.Size(49, 13);
            this.labelVorname.TabIndex = 0;
            this.labelVorname.Text = "Vorname";
            // 
            // bestellungenPodukteInBestellungenBindingSource
            // 
            this.bestellungenPodukteInBestellungenBindingSource.DataMember = "BestellungenPodukteInBestellungen";
            this.bestellungenPodukteInBestellungenBindingSource.DataSource = this.bestellungenBindingSource;
            // 
            // tabControlWrapper
            // 
            this.tabControlWrapper.Controls.Add(this.tabPageBestellung);
            this.tabControlWrapper.Controls.Add(this.tabPageProduktion);
            this.tabControlWrapper.Controls.Add(this.tabPageLager);
            this.tabControlWrapper.Controls.Add(this.tabPageKomissionierung);
            this.tabControlWrapper.Controls.Add(this.tabPageRohstoffe);
            this.tabControlWrapper.Controls.Add(this.tabPageControlling);
            this.tabControlWrapper.Location = new System.Drawing.Point(12, 12);
            this.tabControlWrapper.Name = "tabControlWrapper";
            this.tabControlWrapper.SelectedIndex = 0;
            this.tabControlWrapper.Size = new System.Drawing.Size(1001, 717);
            this.tabControlWrapper.TabIndex = 0;
            // 
            // kundenTableAdapter
            // 
            this.kundenTableAdapter.ClearBeforeFill = true;
            // 
            // produkteTableAdapter
            // 
            this.produkteTableAdapter.ClearBeforeFill = true;
            // 
            // bestellungenTableAdapter
            // 
            this.bestellungenTableAdapter.ClearBeforeFill = true;
            // 
            // bestellungEnthaeltTableAdapter
            // 
            this.bestellungEnthaeltTableAdapter.ClearBeforeFill = true;
            // 
            // baeckerei40DataSetBindingSource
            // 
            this.baeckerei40DataSetBindingSource.DataSource = this.baeckerei40DataSet;
            this.baeckerei40DataSetBindingSource.Position = 0;
            // 
            // rohstoffeTableAdapter
            // 
            this.rohstoffeTableAdapter.ClearBeforeFill = true;
            // 
            // produktEnthaeltTableAdapter
            // 
            this.produktEnthaeltTableAdapter.ClearBeforeFill = true;
            // 
            // rezeptverwaltungTableAdapter
            // 
            this.rezeptverwaltungTableAdapter.ClearBeforeFill = true;
            // 
            // produkteTableAdapter1
            // 
            this.produkteTableAdapter1.ClearBeforeFill = true;
            // 
            // bestellungenTableAdapter1
            // 
            this.bestellungenTableAdapter1.ClearBeforeFill = true;
            // 
            // bestellungEnthaeltTableAdapter1
            // 
            this.bestellungEnthaeltTableAdapter1.ClearBeforeFill = true;
            // 
            // bestellungenTableAdapter2
            // 
            this.bestellungenTableAdapter2.ClearBeforeFill = true;
            // 
            // baeckerei40
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 748);
            this.Controls.Add(this.labelBenutzer);
            this.Controls.Add(this.tabControlWrapper);
            this.MaximizeBox = false;
            this.Name = "baeckerei40";
            this.ShowInTaskbar = false;
            this.Text = "Bäckerei 4.0 - Gruppe 3";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.baeckerei40_FormClosing);
            this.Load += new System.EventHandler(this.baeckerei40_Load);
            this.tabPageRohstoffe.ResumeLayout(false);
            this.panelRez.ResumeLayout(false);
            this.panelRez.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet5)).EndInit();
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produktEnthaeltBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet4)).EndInit();
            this.tabPageKomissionierung.ResumeLayout(false);
            this.panelKom.ResumeLayout(false);
            this.panelKom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet8)).EndInit();
            this.tabPageLager.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rohstoffeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLager)).EndInit();
            this.tabPageProduktion.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktionsliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet)).EndInit();
            this.tabPageBestellung.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridKundenliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenPodukteInBestellungenBindingSource)).EndInit();
            this.tabControlWrapper.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelBenutzer;
        private System.Windows.Forms.TabPage tabPageControlling;
        private System.Windows.Forms.TabPage tabPageRohstoffe;
        private System.Windows.Forms.GroupBox panelRez;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TabPage tabPageKomissionierung;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabPage tabPageLager;
        private System.Windows.Forms.GroupBox panel;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TabPage tabPageProduktion;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridViewProduktionsliste;
        private System.Windows.Forms.Button buttonProduktionSpeichern;
        private System.Windows.Forms.TabPage tabPageBestellung;
        private System.Windows.Forms.Button buttonWarenkorbEntfernen;
        private System.Windows.Forms.Button buttonWarenkorbHinzufuegen;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridViewBestellliste;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox listBoxWarenkorb;
        private System.Windows.Forms.Label labelAbholdatum;
        private System.Windows.Forms.DateTimePicker dateTimePickerAbholdatum;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewProduktliste;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonBearbeiten;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.DataGridView dataGridKundenliste;
        private System.Windows.Forms.TextBox textBoxKundennummer;
        private System.Windows.Forms.Label labelKundennummer;
        private System.Windows.Forms.TextBox textBoxTelefonnummer;
        private System.Windows.Forms.Label labelTelefonnummer;
        private System.Windows.Forms.TextBox textBoxNachname;
        private System.Windows.Forms.Label labelNachname;
        private System.Windows.Forms.TextBox textBoxVorname;
        private System.Windows.Forms.Label labelVorname;
        private System.Windows.Forms.Button buttonBestelllisteSpeichern;
        private System.Windows.Forms.TabControl tabControlWrapper;
        private baeckerei40DataSet baeckerei40DataSet;
        private System.Windows.Forms.BindingSource kundenBindingSource;
        private baeckerei40DataSetTableAdapters.KundenTableAdapter kundenTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kundenIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vornameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nachnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonnummerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLZDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ortDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource produkteBindingSource;
        private baeckerei40DataSetTableAdapters.ProdukteTableAdapter produkteTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktPreisDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bestellungenBindingSource;
        private baeckerei40DataSetTableAdapters.BestellungenTableAdapter bestellungenTableAdapter;
        private System.Windows.Forms.DateTimePicker dateTimePickerAbholzeit;
        private System.Windows.Forms.Label labelAbholzeit;
        private System.Windows.Forms.BindingSource bestellungEnthaeltBindingSource;
        private baeckerei40DataSetTableAdapters.BestellungEnthaeltTableAdapter bestellungEnthaeltTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellungEnthaeltIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellMengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn produziertDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridView dataGridViewLager;
        private System.Windows.Forms.BindingSource baeckerei40DataSetBindingSource;
        private baeckerei40DataSet1 baeckerei40DataSet1;
        private System.Windows.Forms.BindingSource rohstoffeBindingSource;
        private baeckerei40DataSet1TableAdapters.RohstoffeTableAdapter rohstoffeTableAdapter;
        private System.Windows.Forms.Button RBearbeiten;
        private System.Windows.Forms.Button RAbbrechen;
        private System.Windows.Forms.Button RHinzufügen;
        private System.Windows.Forms.TextBox RPreis;
        private System.Windows.Forms.TextBox REinheit;
        private System.Windows.Forms.TextBox LMenge;
        private System.Windows.Forms.TextBox RName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labeli;
        private System.Windows.Forms.TextBox RID;
        private System.Windows.Forms.DataGridView dataGridView2;
        private baeckerei40DataSet4 baeckerei40DataSet4;
        private System.Windows.Forms.BindingSource produktEnthaeltBindingSource;
        private baeckerei40DataSet4TableAdapters.ProduktEnthaeltTableAdapter produktEnthaeltTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffeinheitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffPreisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lagermengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button RSpeichern;
        private baeckerei40DataSet5 baeckerei40DataSet5;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource;
        private baeckerei40DataSet5TableAdapters.RezeptverwaltungTableAdapter rezeptverwaltungTableAdapter;
        private System.Windows.Forms.Button RezSp;
        private System.Windows.Forms.Button RezHinzu;
        private System.Windows.Forms.Button RezBearb;
        private System.Windows.Forms.Button RezAbbr;
        private System.Windows.Forms.TextBox Roheinheit3;
        private System.Windows.Forms.TextBox Rohmenge3;
        private System.Windows.Forms.TextBox Rohname3;
        private System.Windows.Forms.TextBox Roheinheit2;
        private System.Windows.Forms.TextBox Rohmenge2;
        private System.Windows.Forms.TextBox Rohname2;
        private System.Windows.Forms.TextBox Roheinheit1;
        private System.Windows.Forms.TextBox Rohmenge1;
        private System.Windows.Forms.TextBox Rohname1;
        private System.Windows.Forms.TextBox Roheinheit;
        private System.Windows.Forms.TextBox Rohmenge;
        private System.Windows.Forms.TextBox Rohname;
        private System.Windows.Forms.TextBox Rezname;
        private System.Windows.Forms.TextBox RezID;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn RezeptID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RezeptName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge2;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge3;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit3;
        private System.Windows.Forms.DataGridViewTextBoxColumn rezeptIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rezeptNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffmengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffEinheitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffname1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffmenge1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffEinheit1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffname2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffmenge2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffEinheit2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffname3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffmenge3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffEinheit3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridViewPL;
        private baeckerei40DataSet6 baeckerei40DataSet6;
        private System.Windows.Forms.BindingSource produkteBindingSource1;
        private baeckerei40DataSet6TableAdapters.ProdukteTableAdapter produkteTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktPreisDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private baeckerei40DataSet8 baeckerei40DataSet8;
        private System.Windows.Forms.BindingSource bestellungenBindingSource1;
        private baeckerei40DataSet8TableAdapters.BestellungenTableAdapter bestellungenTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private baeckerei40DataSet9 baeckerei40DataSet9;
        private System.Windows.Forms.BindingSource bestellungEnthaeltBindingSource1;
        private baeckerei40DataSet9TableAdapters.BestellungEnthaeltTableAdapter bestellungEnthaeltTableAdapter1;
        private System.Windows.Forms.Button button_mult;
        private System.Windows.Forms.Button button_istgleich;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.TextBox textBox_anzeige;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button plus;
        private baeckerei40DataSet10 baeckerei40DataSet10;
        private System.Windows.Forms.BindingSource bestellungenBindingSource2;
        private baeckerei40DataSet10TableAdapters.BestellungenTableAdapter bestellungenTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellungEnthaeltIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellMengeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn kundenIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn abholdatumDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn abholzeitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn checkbox;
        private System.Windows.Forms.Button Kom_speichern;
        private System.Windows.Forms.Button Kom_bearb;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox Kom_GPreis;
        private System.Windows.Forms.TextBox tb_BestellID;
        private System.Windows.Forms.Panel panelKom;
        private System.Windows.Forms.Button buttonBestellen;
        private System.Windows.Forms.Label labelGesamtpreis;
        private System.Windows.Forms.Label labelWarenkorb;
        private System.Windows.Forms.Button buttonKundeHinzufügen;
        private System.Windows.Forms.Button buttonAenderungProduktliste;
        private System.Windows.Forms.DataGridViewTextBoxColumn KundenID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Abholdatum;
        private System.Windows.Forms.DataGridViewTextBoxColumn Abholzeit;
        private System.Windows.Forms.BindingSource bestellungenPodukteInBestellungenBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn;
    }
}

