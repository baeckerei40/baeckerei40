﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baeckerei40_forms
{
    class Rolle
    {
        public int RollenID { get; set; }
        public String RollenName { get; set; }
    }
}
