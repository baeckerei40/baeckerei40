﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baeckerei40_forms
{
    class Produkt
    {
        public int ProduktID { get; set; }
        public String Produktname{ get; set; }
        public Double ProduktPreis { get; set; }
        public Boolean produziert { get; set; }
        

    }
}
