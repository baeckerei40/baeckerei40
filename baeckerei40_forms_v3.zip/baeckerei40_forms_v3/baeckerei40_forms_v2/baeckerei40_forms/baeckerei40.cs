﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baeckerei40_forms
{
    public partial class baeckerei40 : Form
    {

        public baeckerei40(Mitarbeiter m)
        {
            InitializeComponent();
            labelBenutzer.Text = "Benutzer: " + m.Benutzername;
            //Zeige Tabs je nach Berechtigung
            switch (m.Benutzername)
            {
                case "Manager":                    
                    break;
                case "Verkauf":
                    this.tabControlWrapper.TabPages.Remove(tabPageControlling);
                    this.tabControlWrapper.TabPages.Remove(tabPageRezepte);
                    this.tabControlWrapper.TabPages.Remove(tabPageProduktion);
                    break;
                case "Bäcker":
                    this.tabControlWrapper.TabPages.Remove(tabPageBestellung);
                    this.tabControlWrapper.TabPages.Remove(tabPageControlling);
                    this.tabControlWrapper.TabPages.Remove(tabPageKomissionierung);
                    break;
                default:
                    break;
            }


        }

        private void buttonHinzufuegen_Click(object sender, EventArgs e)
        {
            try
            {
                Kunde k = new Kunde();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hinzufügen fehlgeschlagen.\n" + ex.Message);
            }
        }

        private void dataGridKundenliste_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            textBoxKundennummer.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBoxVorname.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxNachname.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxTelefonnummer.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void buttonBearbeiten_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.dataGridKundenliste.EndEdit();
                this.kundenTableAdapter.Update(this.baeckerei40DataSet.Kunden);
                MessageBox.Show("Update successful");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update failed\n" + ex);
            }
        }

        private void dataGridKundenliste_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void baeckerei40_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet2.Rezeptverwaltung". Sie können sie bei Bedarf verschieben oder entfernen.
            this.rezeptverwaltungTableAdapter.Fill(this.baeckerei40DataSet2.Rezeptverwaltung);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet9.Rezeptverwaltung". Sie können sie bei Bedarf verschieben oder entfernen.
            this.rezeptverwaltungTableAdapter4.Fill(this.baeckerei40DataSet9.Rezeptverwaltung);
          
          
            
           

            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet.BestellungEnthaelt". Sie können sie bei Bedarf verschieben oder entfernen.
            this.bestellungEnthaeltTableAdapter.Fill(this.baeckerei40DataSet.BestellungEnthaelt);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet.Bestellungen". Sie können sie bei Bedarf verschieben oder entfernen.
            this.bestellungenTableAdapter.Fill(this.baeckerei40DataSet.Bestellungen);
            this.produkteTableAdapter.Fill(this.baeckerei40DataSet.Produkte);
            this.kundenTableAdapter.Fill(this.baeckerei40DataSet.Kunden);
            this.rohstoffeTableAdapter.Fill(this.baeckerei40DataSet1.Rohstoffe);
            rohstoffeBindingSource.DataSource = this.baeckerei40DataSet1.Rohstoffe;
            rezeptverwaltungBindingSource.DataSource = this.baeckerei40DataSet9.Rezeptverwaltung;
        }

        private void buttonBestelllisteSpeichern_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.dataGridViewBestellliste.EndEdit();
                this.bestellungenTableAdapter.Update(this.baeckerei40DataSet.Bestellungen);
                MessageBox.Show("Update successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed\n" + ex);
            }
        }

        private void buttonWarenkorbHinzufuegen_Click(object sender, EventArgs e)
        {
            Produkt p = new Produkt();
            try
            {
                var cellIndex = dataGridViewProduktliste.SelectedCells[0].RowIndex;
                var cellCollection = dataGridViewProduktliste.Rows[cellIndex].Cells[0];

                p.ProduktID = (int)dataGridViewProduktliste.Rows[cellIndex].Cells[0].Value;
                p.Produktname = (string)dataGridViewProduktliste.Rows[cellIndex].Cells[1].Value;
                this.listBoxWarenkorb.Items.Add(p.ProduktID.ToString() + " " + p.Produktname.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kein Produkt ausgewählt. \n" + ex);
            }
        }

        private void baeckerei40_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Alle Forms beenden (auch Login)
            Environment.Exit(0);
        }


        private void RHinzufügen_Click(object sender, EventArgs e)
        {
            try
            {
                panel.Enabled = true;
                RID.Focus();
                this.baeckerei40DataSet1.Rohstoffe.AddRohstoffeRow(this.baeckerei40DataSet1.Rohstoffe.NewRohstoffeRow());
                rohstoffeBindingSource.MoveLast();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rohstoffeBindingSource.ResetBindings(false);
            }
        }

        private void dataGridViewLager_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                RID.Text = dataGridViewLager.Rows[e.RowIndex].Cells[0].Value.ToString();
                RName.Text = dataGridViewLager.Rows[e.RowIndex].Cells[1].Value.ToString();
                REinheit.Text = dataGridViewLager.Rows[e.RowIndex].Cells[2].Value.ToString();
                RPreis.Text = dataGridViewLager.Rows[e.RowIndex].Cells[3].Value.ToString();
                LMenge.Text = dataGridViewLager.Rows[e.RowIndex].Cells[4].Value.ToString();
            }

        }

        private void RBearbeiten_Click(object sender, EventArgs e)
        {
            panel.Enabled = true;
            RID.Focus();

        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Delete)
            {
                if (MessageBox.Show("Sind Sie sicher dass Sie das löschen wollen=", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    rohstoffeBindingSource.RemoveCurrent();
                rohstoffeBindingSource.EndEdit();
            }
        }

        private void RSpeichern_Click(object sender, EventArgs e)
        {
            try
            {
                rohstoffeBindingSource.EndEdit();
                rohstoffeTableAdapter.Update(this.baeckerei40DataSet1.Rohstoffe);
                panel.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rohstoffeBindingSource.ResetBindings(false);
            }
        }

        private void RAbbrechen_Click(object sender, EventArgs e)
        {
            panel.Enabled = false;
            rohstoffeBindingSource.ResetBindings(false);
        }

       
        private void RHinzu_Click(object sender, EventArgs e)
        {
            try
            {
                panelR.Enabled = true;
                RezID.Focus();
                this.baeckerei40DataSet9.Rezeptverwaltung.AddRezeptverwaltungRow(baeckerei40DataSet9.Rezeptverwaltung.NewRezeptverwaltungRow());
               rezeptverwaltungBindingSource.MoveLast();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rezeptverwaltungBindingSource.ResetBindings(false);
            }
        }

        private void RBea_Click(object sender, EventArgs e)
        {
            panelR.Enabled = true;
            RezID.Focus();

        }

        private void RAbb_Click(object sender, EventArgs e)
        {
           
                panelR.Enabled = false;
                rezeptverwaltungBindingSource.ResetBindings(false);
           
        }

        private void RS_Click(object sender, EventArgs e)
        {
            try
            {
               rezeptverwaltungBindingSource.EndEdit();
                rezeptverwaltungTableAdapter4.Update(this.baeckerei40DataSet9.Rezeptverwaltung);
                panelR.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rezeptverwaltungBindingSource.ResetBindings(false);
            }
        }

        private void dataGridViewRezepte_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (MessageBox.Show("Sind Sie sicher dass Sie das löschen wollen=", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    rezeptverwaltungBindingSource.RemoveCurrent();
               rezeptverwaltungBindingSource.EndEdit();
            }
        }

        private void dataGridViewRezpte_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                RezID.Text = dataGridViewLager.Rows[e.RowIndex].Cells[0].Value.ToString();
                RezName.Text = dataGridViewLager.Rows[e.RowIndex].Cells[1].Value.ToString();
                RN.Text = dataGridViewLager.Rows[e.RowIndex].Cells[2].Value.ToString();
                RM.Text = dataGridViewLager.Rows[e.RowIndex].Cells[3].Value.ToString();
                RE.Text = dataGridViewLager.Rows[e.RowIndex].Cells[4].Value.ToString();
                RN1.Text = dataGridViewLager.Rows[e.RowIndex].Cells[5].Value.ToString();
                RM1.Text = dataGridViewLager.Rows[e.RowIndex].Cells[6].Value.ToString();
                RE1.Text = dataGridViewLager.Rows[e.RowIndex].Cells[7].Value.ToString();
                RN2.Text = dataGridViewLager.Rows[e.RowIndex].Cells[8].Value.ToString();
                RM2.Text = dataGridViewLager.Rows[e.RowIndex].Cells[9].Value.ToString();
                RE2.Text = dataGridViewLager.Rows[e.RowIndex].Cells[10].Value.ToString();
                RN3.Text = dataGridViewLager.Rows[e.RowIndex].Cells[11].Value.ToString();
                RM3.Text = dataGridViewLager.Rows[e.RowIndex].Cells[12].Value.ToString();
                RE3.Text = dataGridViewLager.Rows[e.RowIndex].Cells[13].Value.ToString();
            }

        }

           }
    }
