﻿namespace baeckerei40_forms
{
    partial class baeckerei40
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelBenutzer = new System.Windows.Forms.Label();
            this.tabPageControlling = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.tabPageRezepte = new System.Windows.Forms.TabPage();
            this.RS = new System.Windows.Forms.Button();
            this.RHinzu = new System.Windows.Forms.Button();
            this.RBea = new System.Windows.Forms.Button();
            this.RAbb = new System.Windows.Forms.Button();
            this.panelR = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.RN1 = new System.Windows.Forms.TextBox();
            this.RN2 = new System.Windows.Forms.TextBox();
            this.RE1 = new System.Windows.Forms.TextBox();
            this.RM2 = new System.Windows.Forms.TextBox();
            this.RM1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.RE2 = new System.Windows.Forms.TextBox();
            this.RE3 = new System.Windows.Forms.TextBox();
            this.RM3 = new System.Windows.Forms.TextBox();
            this.RN3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.RezID = new System.Windows.Forms.TextBox();
            this.RM = new System.Windows.Forms.TextBox();
            this.RN = new System.Windows.Forms.TextBox();
            this.RE = new System.Windows.Forms.TextBox();
            this.RezName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.dataGridViewRezpte = new System.Windows.Forms.DataGridView();
            this.rezeptverwaltungBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet2 = new baeckerei40_forms.baeckerei40DataSet2();
            this.rezeptverwaltungBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet9 = new baeckerei40_forms.baeckerei40DataSet9();
            this.rohstoffeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet1 = new baeckerei40_forms.baeckerei40DataSet1();
            this.rezeptverwaltungBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.produktEnthaeltBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPageKomissionierung = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tabPageLager = new System.Windows.Forms.TabPage();
            this.RSpeichern = new System.Windows.Forms.Button();
            this.panel = new System.Windows.Forms.GroupBox();
            this.labeli = new System.Windows.Forms.Label();
            this.RID = new System.Windows.Forms.TextBox();
            this.RPreis = new System.Windows.Forms.TextBox();
            this.REinheit = new System.Windows.Forms.TextBox();
            this.LMenge = new System.Windows.Forms.TextBox();
            this.RName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridViewLager = new System.Windows.Forms.DataGridView();
            this.rohstoffIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffeinheitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffPreisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lagermengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RHinzufügen = new System.Windows.Forms.Button();
            this.RBearbeiten = new System.Windows.Forms.Button();
            this.RAbbrechen = new System.Windows.Forms.Button();
            this.tabPageProduktion = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellMengeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produziertDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bestellungEnthaeltBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baeckerei40DataSet = new baeckerei40_forms.baeckerei40DataSet();
            this.buttonProduktionSpeichern = new System.Windows.Forms.Button();
            this.tabPageBestellung = new System.Windows.Forms.TabPage();
            this.comboBoxWarenkorbAnzahl = new System.Windows.Forms.ComboBox();
            this.buttonWarenkorbEntfernen = new System.Windows.Forms.Button();
            this.buttonWarenkorbHinzufuegen = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridViewBestellliste = new System.Windows.Forms.DataGridView();
            this.KundenID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Abholdatum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Abholzeit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kundenIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abholdatumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.abholzeitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bestellungenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonBestelllisteSpeichern = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dateTimePickerAbholzeit = new System.Windows.Forms.DateTimePicker();
            this.labelAbholzeit = new System.Windows.Forms.Label();
            this.textBoxBestellID = new System.Windows.Forms.TextBox();
            this.labelBestellID = new System.Windows.Forms.Label();
            this.listBoxWarenkorb = new System.Windows.Forms.ListBox();
            this.labelAbholdatum = new System.Windows.Forms.Label();
            this.dateTimePickerAbholdatum = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewProduktliste = new System.Windows.Forms.DataGridView();
            this.produktIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produktPreisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.produkteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonBearbeiten = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.dataGridKundenliste = new System.Windows.Forms.DataGridView();
            this.kundenIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vornameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nachnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonnummerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pLZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ortDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kundenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBoxKundennummer = new System.Windows.Forms.TextBox();
            this.labelKundennummer = new System.Windows.Forms.Label();
            this.textBoxTelefonnummer = new System.Windows.Forms.TextBox();
            this.labelTelefonnummer = new System.Windows.Forms.Label();
            this.textBoxNachname = new System.Windows.Forms.TextBox();
            this.labelNachname = new System.Windows.Forms.Label();
            this.textBoxVorname = new System.Windows.Forms.TextBox();
            this.labelVorname = new System.Windows.Forms.Label();
            this.tabControlWrapper = new System.Windows.Forms.TabControl();
            this.kundenTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.KundenTableAdapter();
            this.produkteTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.ProdukteTableAdapter();
            this.bestellungenTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.BestellungenTableAdapter();
            this.bestellungEnthaeltTableAdapter = new baeckerei40_forms.baeckerei40DataSetTableAdapters.BestellungEnthaeltTableAdapter();
            this.baeckerei40DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rohstoffeTableAdapter = new baeckerei40_forms.baeckerei40DataSet1TableAdapters.RohstoffeTableAdapter();
            this.rezeptverwaltungBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rezeptverwaltungBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.rezeptverwaltungBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.rezeptverwaltungTableAdapter4 = new baeckerei40_forms.baeckerei40DataSet9TableAdapters.RezeptverwaltungTableAdapter();
            this.rezeptverwaltungTableAdapter = new baeckerei40_forms.baeckerei40DataSet2TableAdapters.RezeptverwaltungTableAdapter();
            this.RezeptID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RezeptName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rohstoffnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffname3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rohstoffmenge3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RohstoffEinheit3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageControlling.SuspendLayout();
            this.tabPageRezepte.SuspendLayout();
            this.panelR.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRezpte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rohstoffeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produktEnthaeltBindingSource)).BeginInit();
            this.tabPageKomissionierung.SuspendLayout();
            this.tabPageLager.SuspendLayout();
            this.panel.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLager)).BeginInit();
            this.tabPageProduktion.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet)).BeginInit();
            this.tabPageBestellung.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridKundenliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).BeginInit();
            this.tabControlWrapper.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // labelBenutzer
            // 
            this.labelBenutzer.AutoSize = true;
            this.labelBenutzer.Location = new System.Drawing.Point(873, 9);
            this.labelBenutzer.Name = "labelBenutzer";
            this.labelBenutzer.Size = new System.Drawing.Size(55, 13);
            this.labelBenutzer.TabIndex = 1;
            this.labelBenutzer.Text = "Benutzer: ";
            // 
            // tabPageControlling
            // 
            this.tabPageControlling.Controls.Add(this.groupBox17);
            this.tabPageControlling.Controls.Add(this.groupBox16);
            this.tabPageControlling.Controls.Add(this.groupBox15);
            this.tabPageControlling.Location = new System.Drawing.Point(4, 22);
            this.tabPageControlling.Name = "tabPageControlling";
            this.tabPageControlling.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageControlling.Size = new System.Drawing.Size(993, 691);
            this.tabPageControlling.TabIndex = 6;
            this.tabPageControlling.Text = "Controlling";
            this.tabPageControlling.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Location = new System.Drawing.Point(670, 12);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(326, 578);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Sonstiges";
            // 
            // groupBox16
            // 
            this.groupBox16.Location = new System.Drawing.Point(338, 9);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(326, 578);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Lager";
            // 
            // groupBox15
            // 
            this.groupBox15.Location = new System.Drawing.Point(6, 6);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(326, 578);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Gewinn";
            // 
            // tabPageRezepte
            // 
            this.tabPageRezepte.Controls.Add(this.RS);
            this.tabPageRezepte.Controls.Add(this.RHinzu);
            this.tabPageRezepte.Controls.Add(this.RBea);
            this.tabPageRezepte.Controls.Add(this.RAbb);
            this.tabPageRezepte.Controls.Add(this.panelR);
            this.tabPageRezepte.Controls.Add(this.groupBox13);
            this.tabPageRezepte.Location = new System.Drawing.Point(4, 22);
            this.tabPageRezepte.Name = "tabPageRezepte";
            this.tabPageRezepte.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRezepte.Size = new System.Drawing.Size(993, 691);
            this.tabPageRezepte.TabIndex = 5;
            this.tabPageRezepte.Text = "Rezepte";
            this.tabPageRezepte.UseVisualStyleBackColor = true;
            // 
            // RS
            // 
            this.RS.Location = new System.Drawing.Point(860, 591);
            this.RS.Name = "RS";
            this.RS.Size = new System.Drawing.Size(97, 55);
            this.RS.TabIndex = 17;
            this.RS.Text = "Speichern";
            this.RS.UseVisualStyleBackColor = true;
            this.RS.Click += new System.EventHandler(this.RS_Click);
            // 
            // RHinzu
            // 
            this.RHinzu.Location = new System.Drawing.Point(860, 403);
            this.RHinzu.Name = "RHinzu";
            this.RHinzu.Size = new System.Drawing.Size(97, 49);
            this.RHinzu.TabIndex = 14;
            this.RHinzu.Text = "Hinzufügen";
            this.RHinzu.UseVisualStyleBackColor = true;
            this.RHinzu.Click += new System.EventHandler(this.RHinzu_Click);
            // 
            // RBea
            // 
            this.RBea.Location = new System.Drawing.Point(860, 464);
            this.RBea.Name = "RBea";
            this.RBea.Size = new System.Drawing.Size(97, 51);
            this.RBea.TabIndex = 16;
            this.RBea.Text = "Bearbeiten";
            this.RBea.UseVisualStyleBackColor = true;
            this.RBea.Click += new System.EventHandler(this.RBea_Click);
            // 
            // RAbb
            // 
            this.RAbb.Location = new System.Drawing.Point(860, 523);
            this.RAbb.Name = "RAbb";
            this.RAbb.Size = new System.Drawing.Size(97, 48);
            this.RAbb.TabIndex = 15;
            this.RAbb.Text = "Abbrechen";
            this.RAbb.UseVisualStyleBackColor = true;
            this.RAbb.Click += new System.EventHandler(this.RAbb_Click);
            // 
            // panelR
            // 
            this.panelR.Controls.Add(this.label15);
            this.panelR.Controls.Add(this.RN1);
            this.panelR.Controls.Add(this.RN2);
            this.panelR.Controls.Add(this.RE1);
            this.panelR.Controls.Add(this.RM2);
            this.panelR.Controls.Add(this.RM1);
            this.panelR.Controls.Add(this.label16);
            this.panelR.Controls.Add(this.label17);
            this.panelR.Controls.Add(this.label18);
            this.panelR.Controls.Add(this.label19);
            this.panelR.Controls.Add(this.label10);
            this.panelR.Controls.Add(this.RE2);
            this.panelR.Controls.Add(this.RE3);
            this.panelR.Controls.Add(this.RM3);
            this.panelR.Controls.Add(this.RN3);
            this.panelR.Controls.Add(this.label12);
            this.panelR.Controls.Add(this.label13);
            this.panelR.Controls.Add(this.label14);
            this.panelR.Controls.Add(this.label5);
            this.panelR.Controls.Add(this.RezID);
            this.panelR.Controls.Add(this.RM);
            this.panelR.Controls.Add(this.RN);
            this.panelR.Controls.Add(this.RE);
            this.panelR.Controls.Add(this.RezName);
            this.panelR.Controls.Add(this.label6);
            this.panelR.Controls.Add(this.label7);
            this.panelR.Controls.Add(this.label8);
            this.panelR.Controls.Add(this.label9);
            this.panelR.Location = new System.Drawing.Point(7, 364);
            this.panelR.Name = "panelR";
            this.panelR.Size = new System.Drawing.Size(810, 321);
            this.panelR.TabIndex = 1;
            this.panelR.TabStop = false;
            this.panelR.Text = "Rezeptanzeige";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(278, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 13);
            this.label15.TabIndex = 42;
            this.label15.Text = "Rohstoffname1";
            // 
            // RN1
            // 
            this.RN1.Location = new System.Drawing.Point(281, 45);
            this.RN1.Name = "RN1";
            this.RN1.Size = new System.Drawing.Size(245, 20);
            this.RN1.TabIndex = 41;
            // 
            // RN2
            // 
            this.RN2.Location = new System.Drawing.Point(281, 213);
            this.RN2.Name = "RN2";
            this.RN2.Size = new System.Drawing.Size(245, 20);
            this.RN2.TabIndex = 40;
            // 
            // RE1
            // 
            this.RE1.Location = new System.Drawing.Point(281, 159);
            this.RE1.Name = "RE1";
            this.RE1.Size = new System.Drawing.Size(245, 20);
            this.RE1.TabIndex = 39;
            // 
            // RM2
            // 
            this.RM2.Location = new System.Drawing.Point(281, 269);
            this.RM2.Name = "RM2";
            this.RM2.Size = new System.Drawing.Size(245, 20);
            this.RM2.TabIndex = 38;
            // 
            // RM1
            // 
            this.RM1.Location = new System.Drawing.Point(281, 96);
            this.RM1.Name = "RM1";
            this.RM1.Size = new System.Drawing.Size(245, 20);
            this.RM1.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(278, 253);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "Rohstoffmenge2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(278, 197);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 35;
            this.label17.Text = "Rohstoffname2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(278, 143);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(85, 13);
            this.label18.TabIndex = 34;
            this.label18.Text = "RohstoffEinheit1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(278, 80);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 13);
            this.label19.TabIndex = 33;
            this.label19.Text = "Rohstoffmenge1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(542, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "RohstoffEinheit2";
            // 
            // RE2
            // 
            this.RE2.Location = new System.Drawing.Point(545, 51);
            this.RE2.Name = "RE2";
            this.RE2.Size = new System.Drawing.Size(245, 20);
            this.RE2.TabIndex = 31;
            // 
            // RE3
            // 
            this.RE3.Location = new System.Drawing.Point(545, 219);
            this.RE3.Name = "RE3";
            this.RE3.Size = new System.Drawing.Size(245, 20);
            this.RE3.TabIndex = 30;
            // 
            // RM3
            // 
            this.RM3.Location = new System.Drawing.Point(545, 165);
            this.RM3.Name = "RM3";
            this.RM3.Size = new System.Drawing.Size(245, 20);
            this.RM3.TabIndex = 29;
            // 
            // RN3
            // 
            this.RN3.Location = new System.Drawing.Point(545, 102);
            this.RN3.Name = "RN3";
            this.RN3.Size = new System.Drawing.Size(245, 20);
            this.RN3.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(542, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "RohstoffEinheit3";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(542, 149);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Rohstoffmenge3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(542, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Rohstoffname3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "RezeptID";
            // 
            // RezID
            // 
            this.RezID.Location = new System.Drawing.Point(17, 45);
            this.RezID.Name = "RezID";
            this.RezID.Size = new System.Drawing.Size(245, 20);
            this.RezID.TabIndex = 21;
            // 
            // RM
            // 
            this.RM.Location = new System.Drawing.Point(17, 213);
            this.RM.Name = "RM";
            this.RM.Size = new System.Drawing.Size(245, 20);
            this.RM.TabIndex = 20;
            // 
            // RN
            // 
            this.RN.Location = new System.Drawing.Point(17, 159);
            this.RN.Name = "RN";
            this.RN.Size = new System.Drawing.Size(245, 20);
            this.RN.TabIndex = 19;
            // 
            // RE
            // 
            this.RE.Location = new System.Drawing.Point(17, 269);
            this.RE.Name = "RE";
            this.RE.Size = new System.Drawing.Size(245, 20);
            this.RE.TabIndex = 18;
            // 
            // RezName
            // 
            this.RezName.Location = new System.Drawing.Point(17, 96);
            this.RezName.Name = "RezName";
            this.RezName.Size = new System.Drawing.Size(245, 20);
            this.RezName.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "RohstoffEinheit";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Rohstoffmenge";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 143);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Rohstoffname";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Rezeptname";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.dataGridViewRezpte);
            this.groupBox13.Location = new System.Drawing.Point(7, 7);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(980, 351);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Rezptliste";
            // 
            // dataGridViewRezpte
            // 
            this.dataGridViewRezpte.AllowDrop = true;
            this.dataGridViewRezpte.AllowUserToOrderColumns = true;
            this.dataGridViewRezpte.AutoGenerateColumns = false;
            this.dataGridViewRezpte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRezpte.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RezeptID,
            this.RezeptName,
            this.rohstoffnameDataGridViewTextBoxColumn1,
            this.Rohstoffmenge,
            this.RohstoffEinheit,
            this.Rohstoffname1,
            this.Rohstoffmenge1,
            this.RohstoffEinheit1,
            this.Rohstoffname2,
            this.Rohstoffmenge2,
            this.RohstoffEinheit2,
            this.Rohstoffname3,
            this.Rohstoffmenge3,
            this.RohstoffEinheit3});
            this.dataGridViewRezpte.DataSource = this.rezeptverwaltungBindingSource5;
            this.dataGridViewRezpte.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridViewRezpte.Location = new System.Drawing.Point(6, 19);
            this.dataGridViewRezpte.Name = "dataGridViewRezpte";
            this.dataGridViewRezpte.ReadOnly = true;
            this.dataGridViewRezpte.Size = new System.Drawing.Size(968, 326);
            this.dataGridViewRezpte.TabIndex = 0;
            this.dataGridViewRezpte.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewRezpte_CellContentClick);
            // 
            // rezeptverwaltungBindingSource5
            // 
            this.rezeptverwaltungBindingSource5.DataMember = "Rezeptverwaltung";
            this.rezeptverwaltungBindingSource5.DataSource = this.baeckerei40DataSet2;
            // 
            // baeckerei40DataSet2
            // 
            this.baeckerei40DataSet2.DataSetName = "baeckerei40DataSet2";
            this.baeckerei40DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rezeptverwaltungBindingSource4
            // 
            this.rezeptverwaltungBindingSource4.DataMember = "Rezeptverwaltung";
            this.rezeptverwaltungBindingSource4.DataSource = this.baeckerei40DataSet9;
            // 
            // baeckerei40DataSet9
            // 
            this.baeckerei40DataSet9.DataSetName = "baeckerei40DataSet9";
            this.baeckerei40DataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rohstoffeBindingSource
            // 
            this.rohstoffeBindingSource.DataMember = "Rohstoffe";
            this.rohstoffeBindingSource.DataSource = this.baeckerei40DataSet1;
            // 
            // baeckerei40DataSet1
            // 
            this.baeckerei40DataSet1.DataSetName = "baeckerei40DataSet1";
            this.baeckerei40DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rezeptverwaltungBindingSource
            // 
            this.rezeptverwaltungBindingSource.DataMember = "Rezeptverwaltung";
            // 
            // produktEnthaeltBindingSource
            // 
            this.produktEnthaeltBindingSource.DataMember = "ProduktEnthaelt";
            // 
            // tabPageKomissionierung
            // 
            this.tabPageKomissionierung.Controls.Add(this.groupBox10);
            this.tabPageKomissionierung.Controls.Add(this.groupBox9);
            this.tabPageKomissionierung.Location = new System.Drawing.Point(4, 22);
            this.tabPageKomissionierung.Name = "tabPageKomissionierung";
            this.tabPageKomissionierung.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageKomissionierung.Size = new System.Drawing.Size(993, 691);
            this.tabPageKomissionierung.TabIndex = 3;
            this.tabPageKomissionierung.Text = "Komissionierung";
            this.tabPageKomissionierung.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Location = new System.Drawing.Point(6, 265);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(964, 319);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Bestellungsdetails";
            // 
            // groupBox9
            // 
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(964, 253);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Abholliste";
            // 
            // tabPageLager
            // 
            this.tabPageLager.Controls.Add(this.RSpeichern);
            this.tabPageLager.Controls.Add(this.panel);
            this.tabPageLager.Controls.Add(this.groupBox7);
            this.tabPageLager.Controls.Add(this.RHinzufügen);
            this.tabPageLager.Controls.Add(this.RBearbeiten);
            this.tabPageLager.Controls.Add(this.RAbbrechen);
            this.tabPageLager.Location = new System.Drawing.Point(4, 22);
            this.tabPageLager.Name = "tabPageLager";
            this.tabPageLager.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLager.Size = new System.Drawing.Size(993, 691);
            this.tabPageLager.TabIndex = 2;
            this.tabPageLager.Text = "Lager";
            this.tabPageLager.UseVisualStyleBackColor = true;
            // 
            // RSpeichern
            // 
            this.RSpeichern.Location = new System.Drawing.Point(779, 544);
            this.RSpeichern.Name = "RSpeichern";
            this.RSpeichern.Size = new System.Drawing.Size(97, 55);
            this.RSpeichern.TabIndex = 13;
            this.RSpeichern.Text = "Speichern";
            this.RSpeichern.UseVisualStyleBackColor = true;
            this.RSpeichern.Click += new System.EventHandler(this.RSpeichern_Click);
            // 
            // panel
            // 
            this.panel.Controls.Add(this.labeli);
            this.panel.Controls.Add(this.RID);
            this.panel.Controls.Add(this.RPreis);
            this.panel.Controls.Add(this.REinheit);
            this.panel.Controls.Add(this.LMenge);
            this.panel.Controls.Add(this.RName);
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label1);
            this.panel.Location = new System.Drawing.Point(9, 319);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(720, 310);
            this.panel.TabIndex = 1;
            this.panel.TabStop = false;
            this.panel.Text = "Bestände buchen";
            // 
            // labeli
            // 
            this.labeli.AutoSize = true;
            this.labeli.Location = new System.Drawing.Point(26, 16);
            this.labeli.Name = "labeli";
            this.labeli.Size = new System.Drawing.Size(58, 13);
            this.labeli.TabIndex = 12;
            this.labeli.Text = "RohstoffID";
            // 
            // RID
            // 
            this.RID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "RohstoffID", true));
            this.RID.Location = new System.Drawing.Point(29, 38);
            this.RID.Name = "RID";
            this.RID.Size = new System.Drawing.Size(245, 20);
            this.RID.TabIndex = 11;
            // 
            // RPreis
            // 
            this.RPreis.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "RohstoffPreis", true));
            this.RPreis.Location = new System.Drawing.Point(29, 206);
            this.RPreis.Name = "RPreis";
            this.RPreis.Size = new System.Drawing.Size(245, 20);
            this.RPreis.TabIndex = 7;
            // 
            // REinheit
            // 
            this.REinheit.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Rohstoffeinheit", true));
            this.REinheit.Location = new System.Drawing.Point(29, 152);
            this.REinheit.Name = "REinheit";
            this.REinheit.Size = new System.Drawing.Size(245, 20);
            this.REinheit.TabIndex = 6;
            // 
            // LMenge
            // 
            this.LMenge.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Lagermenge", true));
            this.LMenge.Location = new System.Drawing.Point(29, 262);
            this.LMenge.Name = "LMenge";
            this.LMenge.Size = new System.Drawing.Size(245, 20);
            this.LMenge.TabIndex = 5;
            // 
            // RName
            // 
            this.RName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rohstoffeBindingSource, "Rohstoffname", true));
            this.RName.Location = new System.Drawing.Point(29, 89);
            this.RName.Name = "RName";
            this.RName.Size = new System.Drawing.Size(245, 20);
            this.RName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Lagermenge";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Rohstoffpreis";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Rohstoffeinheit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rohstoffname";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dataGridViewLager);
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(964, 307);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lagerliste";
            // 
            // dataGridViewLager
            // 
            this.dataGridViewLager.AutoGenerateColumns = false;
            this.dataGridViewLager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLager.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rohstoffIDDataGridViewTextBoxColumn,
            this.rohstoffnameDataGridViewTextBoxColumn,
            this.rohstoffeinheitDataGridViewTextBoxColumn,
            this.rohstoffPreisDataGridViewTextBoxColumn,
            this.lagermengeDataGridViewTextBoxColumn});
            this.dataGridViewLager.DataSource = this.rohstoffeBindingSource;
            this.dataGridViewLager.Location = new System.Drawing.Point(32, 31);
            this.dataGridViewLager.Name = "dataGridViewLager";
            this.dataGridViewLager.Size = new System.Drawing.Size(886, 231);
            this.dataGridViewLager.TabIndex = 0;
            this.dataGridViewLager.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLager_CellContentClick);
            this.dataGridViewLager.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // rohstoffIDDataGridViewTextBoxColumn
            // 
            this.rohstoffIDDataGridViewTextBoxColumn.DataPropertyName = "RohstoffID";
            this.rohstoffIDDataGridViewTextBoxColumn.HeaderText = "RohstoffID";
            this.rohstoffIDDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.rohstoffIDDataGridViewTextBoxColumn.Name = "rohstoffIDDataGridViewTextBoxColumn";
            // 
            // rohstoffnameDataGridViewTextBoxColumn
            // 
            this.rohstoffnameDataGridViewTextBoxColumn.DataPropertyName = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn.HeaderText = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn.Name = "rohstoffnameDataGridViewTextBoxColumn";
            // 
            // rohstoffeinheitDataGridViewTextBoxColumn
            // 
            this.rohstoffeinheitDataGridViewTextBoxColumn.DataPropertyName = "Rohstoffeinheit";
            this.rohstoffeinheitDataGridViewTextBoxColumn.HeaderText = "Rohstoffeinheit";
            this.rohstoffeinheitDataGridViewTextBoxColumn.Name = "rohstoffeinheitDataGridViewTextBoxColumn";
            // 
            // rohstoffPreisDataGridViewTextBoxColumn
            // 
            this.rohstoffPreisDataGridViewTextBoxColumn.DataPropertyName = "RohstoffPreis";
            this.rohstoffPreisDataGridViewTextBoxColumn.HeaderText = "RohstoffPreis";
            this.rohstoffPreisDataGridViewTextBoxColumn.Name = "rohstoffPreisDataGridViewTextBoxColumn";
            // 
            // lagermengeDataGridViewTextBoxColumn
            // 
            this.lagermengeDataGridViewTextBoxColumn.DataPropertyName = "Lagermenge";
            this.lagermengeDataGridViewTextBoxColumn.HeaderText = "Lagermenge";
            this.lagermengeDataGridViewTextBoxColumn.Name = "lagermengeDataGridViewTextBoxColumn";
            // 
            // RHinzufügen
            // 
            this.RHinzufügen.Location = new System.Drawing.Point(779, 356);
            this.RHinzufügen.Name = "RHinzufügen";
            this.RHinzufügen.Size = new System.Drawing.Size(97, 49);
            this.RHinzufügen.TabIndex = 8;
            this.RHinzufügen.Text = "Hinzufügen";
            this.RHinzufügen.UseVisualStyleBackColor = true;
            this.RHinzufügen.Click += new System.EventHandler(this.RHinzufügen_Click);
            // 
            // RBearbeiten
            // 
            this.RBearbeiten.Location = new System.Drawing.Point(779, 417);
            this.RBearbeiten.Name = "RBearbeiten";
            this.RBearbeiten.Size = new System.Drawing.Size(97, 51);
            this.RBearbeiten.TabIndex = 10;
            this.RBearbeiten.Text = "Bearbeiten";
            this.RBearbeiten.UseVisualStyleBackColor = true;
            this.RBearbeiten.Click += new System.EventHandler(this.RBearbeiten_Click);
            // 
            // RAbbrechen
            // 
            this.RAbbrechen.Location = new System.Drawing.Point(779, 476);
            this.RAbbrechen.Name = "RAbbrechen";
            this.RAbbrechen.Size = new System.Drawing.Size(97, 48);
            this.RAbbrechen.TabIndex = 9;
            this.RAbbrechen.Text = "Abbrechen";
            this.RAbbrechen.UseVisualStyleBackColor = true;
            this.RAbbrechen.Click += new System.EventHandler(this.RAbbrechen_Click);
            // 
            // tabPageProduktion
            // 
            this.tabPageProduktion.Controls.Add(this.groupBox6);
            this.tabPageProduktion.Controls.Add(this.groupBox5);
            this.tabPageProduktion.Controls.Add(this.buttonProduktionSpeichern);
            this.tabPageProduktion.Location = new System.Drawing.Point(4, 22);
            this.tabPageProduktion.Name = "tabPageProduktion";
            this.tabPageProduktion.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProduktion.Size = new System.Drawing.Size(993, 691);
            this.tabPageProduktion.TabIndex = 1;
            this.tabPageProduktion.Text = "Produktion";
            this.tabPageProduktion.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(3, 319);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(967, 335);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Details";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridView1);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(964, 307);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Produktionsliste";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn,
            this.bestellIDDataGridViewTextBoxColumn1,
            this.produktIDDataGridViewTextBoxColumn1,
            this.bestellMengeDataGridViewTextBoxColumn,
            this.produziertDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.bestellungEnthaeltBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(6, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(958, 282);
            this.dataGridView1.TabIndex = 0;
            // 
            // bestellungEnthaeltIDDataGridViewTextBoxColumn
            // 
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.DataPropertyName = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.HeaderText = "BestellungEnthaeltID";
            this.bestellungEnthaeltIDDataGridViewTextBoxColumn.Name = "bestellungEnthaeltIDDataGridViewTextBoxColumn";
            // 
            // bestellIDDataGridViewTextBoxColumn1
            // 
            this.bestellIDDataGridViewTextBoxColumn1.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn1.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn1.Name = "bestellIDDataGridViewTextBoxColumn1";
            // 
            // produktIDDataGridViewTextBoxColumn1
            // 
            this.produktIDDataGridViewTextBoxColumn1.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn1.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn1.Name = "produktIDDataGridViewTextBoxColumn1";
            // 
            // bestellMengeDataGridViewTextBoxColumn
            // 
            this.bestellMengeDataGridViewTextBoxColumn.DataPropertyName = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn.HeaderText = "BestellMenge";
            this.bestellMengeDataGridViewTextBoxColumn.Name = "bestellMengeDataGridViewTextBoxColumn";
            // 
            // produziertDataGridViewCheckBoxColumn
            // 
            this.produziertDataGridViewCheckBoxColumn.DataPropertyName = "Produziert";
            this.produziertDataGridViewCheckBoxColumn.HeaderText = "Produziert";
            this.produziertDataGridViewCheckBoxColumn.Name = "produziertDataGridViewCheckBoxColumn";
            // 
            // bestellungEnthaeltBindingSource
            // 
            this.bestellungEnthaeltBindingSource.DataMember = "BestellungEnthaelt";
            this.bestellungEnthaeltBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // baeckerei40DataSet
            // 
            this.baeckerei40DataSet.DataSetName = "baeckerei40DataSet";
            this.baeckerei40DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonProduktionSpeichern
            // 
            this.buttonProduktionSpeichern.Location = new System.Drawing.Point(3, 660);
            this.buttonProduktionSpeichern.Name = "buttonProduktionSpeichern";
            this.buttonProduktionSpeichern.Size = new System.Drawing.Size(162, 23);
            this.buttonProduktionSpeichern.TabIndex = 0;
            this.buttonProduktionSpeichern.Text = "Produktion Speichern";
            this.buttonProduktionSpeichern.UseVisualStyleBackColor = true;
            // 
            // tabPageBestellung
            // 
            this.tabPageBestellung.AutoScroll = true;
            this.tabPageBestellung.Controls.Add(this.comboBoxWarenkorbAnzahl);
            this.tabPageBestellung.Controls.Add(this.buttonWarenkorbEntfernen);
            this.tabPageBestellung.Controls.Add(this.buttonWarenkorbHinzufuegen);
            this.tabPageBestellung.Controls.Add(this.groupBox4);
            this.tabPageBestellung.Controls.Add(this.groupBox3);
            this.tabPageBestellung.Controls.Add(this.groupBox2);
            this.tabPageBestellung.Controls.Add(this.groupBox1);
            this.tabPageBestellung.Location = new System.Drawing.Point(4, 22);
            this.tabPageBestellung.Name = "tabPageBestellung";
            this.tabPageBestellung.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBestellung.Size = new System.Drawing.Size(993, 691);
            this.tabPageBestellung.TabIndex = 0;
            this.tabPageBestellung.Text = "Bestellung";
            this.tabPageBestellung.UseVisualStyleBackColor = true;
            // 
            // comboBoxWarenkorbAnzahl
            // 
            this.comboBoxWarenkorbAnzahl.FormattingEnabled = true;
            this.comboBoxWarenkorbAnzahl.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxWarenkorbAnzahl.Location = new System.Drawing.Point(541, 322);
            this.comboBoxWarenkorbAnzahl.Name = "comboBoxWarenkorbAnzahl";
            this.comboBoxWarenkorbAnzahl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBoxWarenkorbAnzahl.Size = new System.Drawing.Size(57, 21);
            this.comboBoxWarenkorbAnzahl.TabIndex = 6;
            this.comboBoxWarenkorbAnzahl.Text = "1";
            // 
            // buttonWarenkorbEntfernen
            // 
            this.buttonWarenkorbEntfernen.Location = new System.Drawing.Point(541, 349);
            this.buttonWarenkorbEntfernen.Name = "buttonWarenkorbEntfernen";
            this.buttonWarenkorbEntfernen.Size = new System.Drawing.Size(58, 23);
            this.buttonWarenkorbEntfernen.TabIndex = 5;
            this.buttonWarenkorbEntfernen.Text = ">>";
            this.buttonWarenkorbEntfernen.UseVisualStyleBackColor = true;
            // 
            // buttonWarenkorbHinzufuegen
            // 
            this.buttonWarenkorbHinzufuegen.Location = new System.Drawing.Point(541, 293);
            this.buttonWarenkorbHinzufuegen.Name = "buttonWarenkorbHinzufuegen";
            this.buttonWarenkorbHinzufuegen.Size = new System.Drawing.Size(58, 23);
            this.buttonWarenkorbHinzufuegen.TabIndex = 4;
            this.buttonWarenkorbHinzufuegen.Text = "<<";
            this.buttonWarenkorbHinzufuegen.UseVisualStyleBackColor = true;
            this.buttonWarenkorbHinzufuegen.Click += new System.EventHandler(this.buttonWarenkorbHinzufuegen_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridViewBestellliste);
            this.groupBox4.Controls.Add(this.buttonBestelllisteSpeichern);
            this.groupBox4.Location = new System.Drawing.Point(6, 451);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(972, 218);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bestellliste";
            // 
            // dataGridViewBestellliste
            // 
            this.dataGridViewBestellliste.AllowUserToOrderColumns = true;
            this.dataGridViewBestellliste.AutoGenerateColumns = false;
            this.dataGridViewBestellliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBestellliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.KundenID,
            this.Abholdatum,
            this.Abholzeit,
            this.bestellIDDataGridViewTextBoxColumn,
            this.kundenIDDataGridViewTextBoxColumn1,
            this.abholdatumDataGridViewTextBoxColumn,
            this.abholzeitDataGridViewTextBoxColumn});
            this.dataGridViewBestellliste.DataSource = this.bestellungenBindingSource;
            this.dataGridViewBestellliste.Location = new System.Drawing.Point(10, 19);
            this.dataGridViewBestellliste.Name = "dataGridViewBestellliste";
            this.dataGridViewBestellliste.Size = new System.Drawing.Size(942, 168);
            this.dataGridViewBestellliste.TabIndex = 2;
            // 
            // KundenID
            // 
            this.KundenID.DataPropertyName = "KundenID";
            this.KundenID.HeaderText = "KundenID";
            this.KundenID.Name = "KundenID";
            // 
            // Abholdatum
            // 
            this.Abholdatum.DataPropertyName = "Abholdatum";
            this.Abholdatum.HeaderText = "Abholdatum";
            this.Abholdatum.Name = "Abholdatum";
            // 
            // Abholzeit
            // 
            this.Abholzeit.DataPropertyName = "Abholzeit";
            this.Abholzeit.HeaderText = "Abholzeit";
            this.Abholzeit.Name = "Abholzeit";
            // 
            // bestellIDDataGridViewTextBoxColumn
            // 
            this.bestellIDDataGridViewTextBoxColumn.DataPropertyName = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn.HeaderText = "BestellID";
            this.bestellIDDataGridViewTextBoxColumn.Name = "bestellIDDataGridViewTextBoxColumn";
            // 
            // kundenIDDataGridViewTextBoxColumn1
            // 
            this.kundenIDDataGridViewTextBoxColumn1.DataPropertyName = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn1.HeaderText = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn1.Name = "kundenIDDataGridViewTextBoxColumn1";
            // 
            // abholdatumDataGridViewTextBoxColumn
            // 
            this.abholdatumDataGridViewTextBoxColumn.DataPropertyName = "Abholdatum";
            this.abholdatumDataGridViewTextBoxColumn.HeaderText = "Abholdatum";
            this.abholdatumDataGridViewTextBoxColumn.Name = "abholdatumDataGridViewTextBoxColumn";
            // 
            // abholzeitDataGridViewTextBoxColumn
            // 
            this.abholzeitDataGridViewTextBoxColumn.DataPropertyName = "Abholzeit";
            this.abholzeitDataGridViewTextBoxColumn.HeaderText = "Abholzeit";
            this.abholzeitDataGridViewTextBoxColumn.Name = "abholzeitDataGridViewTextBoxColumn";
            // 
            // bestellungenBindingSource
            // 
            this.bestellungenBindingSource.DataMember = "Bestellungen";
            this.bestellungenBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // buttonBestelllisteSpeichern
            // 
            this.buttonBestelllisteSpeichern.Location = new System.Drawing.Point(12, 193);
            this.buttonBestelllisteSpeichern.Name = "buttonBestelllisteSpeichern";
            this.buttonBestelllisteSpeichern.Size = new System.Drawing.Size(123, 23);
            this.buttonBestelllisteSpeichern.TabIndex = 7;
            this.buttonBestelllisteSpeichern.Text = "Bestellliste speichern";
            this.buttonBestelllisteSpeichern.Click += new System.EventHandler(this.buttonBestelllisteSpeichern_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dateTimePickerAbholzeit);
            this.groupBox3.Controls.Add(this.labelAbholzeit);
            this.groupBox3.Controls.Add(this.textBoxBestellID);
            this.groupBox3.Controls.Add(this.labelBestellID);
            this.groupBox3.Controls.Add(this.listBoxWarenkorb);
            this.groupBox3.Controls.Add(this.labelAbholdatum);
            this.groupBox3.Controls.Add(this.dateTimePickerAbholdatum);
            this.groupBox3.Location = new System.Drawing.Point(7, 185);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(592, 260);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Warenkorb";
            // 
            // dateTimePickerAbholzeit
            // 
            this.dateTimePickerAbholzeit.CustomFormat = "";
            this.dateTimePickerAbholzeit.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerAbholzeit.Location = new System.Drawing.Point(459, 24);
            this.dateTimePickerAbholzeit.Name = "dateTimePickerAbholzeit";
            this.dateTimePickerAbholzeit.Size = new System.Drawing.Size(69, 20);
            this.dateTimePickerAbholzeit.TabIndex = 23;
            // 
            // labelAbholzeit
            // 
            this.labelAbholzeit.AutoSize = true;
            this.labelAbholzeit.Location = new System.Drawing.Point(403, 27);
            this.labelAbholzeit.Name = "labelAbholzeit";
            this.labelAbholzeit.Size = new System.Drawing.Size(50, 13);
            this.labelAbholzeit.TabIndex = 22;
            this.labelAbholzeit.Text = "Abholzeit";
            // 
            // textBoxBestellID
            // 
            this.textBoxBestellID.Location = new System.Drawing.Point(74, 21);
            this.textBoxBestellID.Name = "textBoxBestellID";
            this.textBoxBestellID.Size = new System.Drawing.Size(82, 20);
            this.textBoxBestellID.TabIndex = 14;
            // 
            // labelBestellID
            // 
            this.labelBestellID.AutoSize = true;
            this.labelBestellID.Location = new System.Drawing.Point(16, 27);
            this.labelBestellID.Name = "labelBestellID";
            this.labelBestellID.Size = new System.Drawing.Size(49, 13);
            this.labelBestellID.TabIndex = 14;
            this.labelBestellID.Text = "BestellID";
            // 
            // listBoxWarenkorb
            // 
            this.listBoxWarenkorb.FormattingEnabled = true;
            this.listBoxWarenkorb.Location = new System.Drawing.Point(7, 53);
            this.listBoxWarenkorb.Name = "listBoxWarenkorb";
            this.listBoxWarenkorb.Size = new System.Drawing.Size(521, 199);
            this.listBoxWarenkorb.TabIndex = 21;
            // 
            // labelAbholdatum
            // 
            this.labelAbholdatum.AutoSize = true;
            this.labelAbholdatum.Location = new System.Drawing.Point(237, 24);
            this.labelAbholdatum.Name = "labelAbholdatum";
            this.labelAbholdatum.Size = new System.Drawing.Size(63, 13);
            this.labelAbholdatum.TabIndex = 20;
            this.labelAbholdatum.Text = "Abholdatum";
            // 
            // dateTimePickerAbholdatum
            // 
            this.dateTimePickerAbholdatum.CustomFormat = "";
            this.dateTimePickerAbholdatum.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerAbholdatum.Location = new System.Drawing.Point(306, 21);
            this.dateTimePickerAbholdatum.Name = "dateTimePickerAbholdatum";
            this.dateTimePickerAbholdatum.Size = new System.Drawing.Size(91, 20);
            this.dateTimePickerAbholdatum.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewProduktliste);
            this.groupBox2.Location = new System.Drawing.Point(605, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 260);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Produktliste";
            // 
            // dataGridViewProduktliste
            // 
            this.dataGridViewProduktliste.AllowUserToOrderColumns = true;
            this.dataGridViewProduktliste.AutoGenerateColumns = false;
            this.dataGridViewProduktliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduktliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.produktIDDataGridViewTextBoxColumn,
            this.produktNameDataGridViewTextBoxColumn,
            this.produktPreisDataGridViewTextBoxColumn});
            this.dataGridViewProduktliste.DataSource = this.produkteBindingSource;
            this.dataGridViewProduktliste.Location = new System.Drawing.Point(5, 19);
            this.dataGridViewProduktliste.Name = "dataGridViewProduktliste";
            this.dataGridViewProduktliste.Size = new System.Drawing.Size(345, 233);
            this.dataGridViewProduktliste.TabIndex = 1;
            // 
            // produktIDDataGridViewTextBoxColumn
            // 
            this.produktIDDataGridViewTextBoxColumn.DataPropertyName = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn.HeaderText = "ProduktID";
            this.produktIDDataGridViewTextBoxColumn.Name = "produktIDDataGridViewTextBoxColumn";
            // 
            // produktNameDataGridViewTextBoxColumn
            // 
            this.produktNameDataGridViewTextBoxColumn.DataPropertyName = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn.HeaderText = "ProduktName";
            this.produktNameDataGridViewTextBoxColumn.Name = "produktNameDataGridViewTextBoxColumn";
            // 
            // produktPreisDataGridViewTextBoxColumn
            // 
            this.produktPreisDataGridViewTextBoxColumn.DataPropertyName = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn.HeaderText = "ProduktPreis";
            this.produktPreisDataGridViewTextBoxColumn.Name = "produktPreisDataGridViewTextBoxColumn";
            // 
            // produkteBindingSource
            // 
            this.produkteBindingSource.DataMember = "Produkte";
            this.produkteBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonBearbeiten);
            this.groupBox1.Controls.Add(this.groupBox18);
            this.groupBox1.Controls.Add(this.textBoxKundennummer);
            this.groupBox1.Controls.Add(this.labelKundennummer);
            this.groupBox1.Controls.Add(this.textBoxTelefonnummer);
            this.groupBox1.Controls.Add(this.labelTelefonnummer);
            this.groupBox1.Controls.Add(this.textBoxNachname);
            this.groupBox1.Controls.Add(this.labelNachname);
            this.groupBox1.Controls.Add(this.textBoxVorname);
            this.groupBox1.Controls.Add(this.labelVorname);
            this.groupBox1.Location = new System.Drawing.Point(7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(971, 175);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kunde";
            // 
            // buttonBearbeiten
            // 
            this.buttonBearbeiten.Location = new System.Drawing.Point(184, 123);
            this.buttonBearbeiten.Name = "buttonBearbeiten";
            this.buttonBearbeiten.Size = new System.Drawing.Size(75, 23);
            this.buttonBearbeiten.TabIndex = 13;
            this.buttonBearbeiten.Text = "bearbeiten";
            this.buttonBearbeiten.UseVisualStyleBackColor = true;
            this.buttonBearbeiten.Click += new System.EventHandler(this.buttonBearbeiten_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.dataGridKundenliste);
            this.groupBox18.Location = new System.Drawing.Point(279, 17);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(692, 158);
            this.groupBox18.TabIndex = 12;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Kundenliste";
            // 
            // dataGridKundenliste
            // 
            this.dataGridKundenliste.AllowUserToOrderColumns = true;
            this.dataGridKundenliste.AutoGenerateColumns = false;
            this.dataGridKundenliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridKundenliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kundenIDDataGridViewTextBoxColumn,
            this.vornameDataGridViewTextBoxColumn,
            this.nachnameDataGridViewTextBoxColumn,
            this.telefonnummerDataGridViewTextBoxColumn,
            this.eMailDataGridViewTextBoxColumn,
            this.adresseDataGridViewTextBoxColumn,
            this.pLZDataGridViewTextBoxColumn,
            this.ortDataGridViewTextBoxColumn});
            this.dataGridKundenliste.DataSource = this.kundenBindingSource;
            this.dataGridKundenliste.Location = new System.Drawing.Point(8, 19);
            this.dataGridKundenliste.Name = "dataGridKundenliste";
            this.dataGridKundenliste.Size = new System.Drawing.Size(664, 119);
            this.dataGridKundenliste.TabIndex = 0;
            this.dataGridKundenliste.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridKundenliste_CellContentClick);
            this.dataGridKundenliste.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridKundenliste_CellDoubleClick);
            // 
            // kundenIDDataGridViewTextBoxColumn
            // 
            this.kundenIDDataGridViewTextBoxColumn.DataPropertyName = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn.HeaderText = "KundenID";
            this.kundenIDDataGridViewTextBoxColumn.Name = "kundenIDDataGridViewTextBoxColumn";
            // 
            // vornameDataGridViewTextBoxColumn
            // 
            this.vornameDataGridViewTextBoxColumn.DataPropertyName = "Vorname";
            this.vornameDataGridViewTextBoxColumn.HeaderText = "Vorname";
            this.vornameDataGridViewTextBoxColumn.Name = "vornameDataGridViewTextBoxColumn";
            // 
            // nachnameDataGridViewTextBoxColumn
            // 
            this.nachnameDataGridViewTextBoxColumn.DataPropertyName = "Nachname";
            this.nachnameDataGridViewTextBoxColumn.HeaderText = "Nachname";
            this.nachnameDataGridViewTextBoxColumn.Name = "nachnameDataGridViewTextBoxColumn";
            // 
            // telefonnummerDataGridViewTextBoxColumn
            // 
            this.telefonnummerDataGridViewTextBoxColumn.DataPropertyName = "Telefonnummer";
            this.telefonnummerDataGridViewTextBoxColumn.HeaderText = "Telefonnummer";
            this.telefonnummerDataGridViewTextBoxColumn.Name = "telefonnummerDataGridViewTextBoxColumn";
            // 
            // eMailDataGridViewTextBoxColumn
            // 
            this.eMailDataGridViewTextBoxColumn.DataPropertyName = "EMail";
            this.eMailDataGridViewTextBoxColumn.HeaderText = "EMail";
            this.eMailDataGridViewTextBoxColumn.Name = "eMailDataGridViewTextBoxColumn";
            // 
            // adresseDataGridViewTextBoxColumn
            // 
            this.adresseDataGridViewTextBoxColumn.DataPropertyName = "Adresse";
            this.adresseDataGridViewTextBoxColumn.HeaderText = "Adresse";
            this.adresseDataGridViewTextBoxColumn.Name = "adresseDataGridViewTextBoxColumn";
            // 
            // pLZDataGridViewTextBoxColumn
            // 
            this.pLZDataGridViewTextBoxColumn.DataPropertyName = "PLZ";
            this.pLZDataGridViewTextBoxColumn.HeaderText = "PLZ";
            this.pLZDataGridViewTextBoxColumn.Name = "pLZDataGridViewTextBoxColumn";
            // 
            // ortDataGridViewTextBoxColumn
            // 
            this.ortDataGridViewTextBoxColumn.DataPropertyName = "Ort";
            this.ortDataGridViewTextBoxColumn.HeaderText = "Ort";
            this.ortDataGridViewTextBoxColumn.Name = "ortDataGridViewTextBoxColumn";
            // 
            // kundenBindingSource
            // 
            this.kundenBindingSource.DataMember = "Kunden";
            this.kundenBindingSource.DataSource = this.baeckerei40DataSet;
            // 
            // textBoxKundennummer
            // 
            this.textBoxKundennummer.Location = new System.Drawing.Point(103, 19);
            this.textBoxKundennummer.Name = "textBoxKundennummer";
            this.textBoxKundennummer.Size = new System.Drawing.Size(161, 20);
            this.textBoxKundennummer.TabIndex = 11;
            // 
            // labelKundennummer
            // 
            this.labelKundennummer.AutoSize = true;
            this.labelKundennummer.Location = new System.Drawing.Point(6, 20);
            this.labelKundennummer.Name = "labelKundennummer";
            this.labelKundennummer.Size = new System.Drawing.Size(81, 13);
            this.labelKundennummer.TabIndex = 10;
            this.labelKundennummer.Text = "Kundennummer";
            // 
            // textBoxTelefonnummer
            // 
            this.textBoxTelefonnummer.Location = new System.Drawing.Point(103, 97);
            this.textBoxTelefonnummer.Name = "textBoxTelefonnummer";
            this.textBoxTelefonnummer.Size = new System.Drawing.Size(161, 20);
            this.textBoxTelefonnummer.TabIndex = 9;
            // 
            // labelTelefonnummer
            // 
            this.labelTelefonnummer.AutoSize = true;
            this.labelTelefonnummer.Location = new System.Drawing.Point(6, 95);
            this.labelTelefonnummer.Name = "labelTelefonnummer";
            this.labelTelefonnummer.Size = new System.Drawing.Size(80, 13);
            this.labelTelefonnummer.TabIndex = 8;
            this.labelTelefonnummer.Text = "Telefonnummer";
            // 
            // textBoxNachname
            // 
            this.textBoxNachname.Location = new System.Drawing.Point(103, 71);
            this.textBoxNachname.Name = "textBoxNachname";
            this.textBoxNachname.Size = new System.Drawing.Size(161, 20);
            this.textBoxNachname.TabIndex = 3;
            // 
            // labelNachname
            // 
            this.labelNachname.AutoSize = true;
            this.labelNachname.Location = new System.Drawing.Point(6, 66);
            this.labelNachname.Name = "labelNachname";
            this.labelNachname.Size = new System.Drawing.Size(59, 13);
            this.labelNachname.TabIndex = 2;
            this.labelNachname.Text = "Nachname";
            // 
            // textBoxVorname
            // 
            this.textBoxVorname.Location = new System.Drawing.Point(103, 45);
            this.textBoxVorname.Name = "textBoxVorname";
            this.textBoxVorname.Size = new System.Drawing.Size(161, 20);
            this.textBoxVorname.TabIndex = 1;
            // 
            // labelVorname
            // 
            this.labelVorname.AutoSize = true;
            this.labelVorname.Location = new System.Drawing.Point(6, 41);
            this.labelVorname.Name = "labelVorname";
            this.labelVorname.Size = new System.Drawing.Size(49, 13);
            this.labelVorname.TabIndex = 0;
            this.labelVorname.Text = "Vorname";
            // 
            // tabControlWrapper
            // 
            this.tabControlWrapper.Controls.Add(this.tabPageBestellung);
            this.tabControlWrapper.Controls.Add(this.tabPageProduktion);
            this.tabControlWrapper.Controls.Add(this.tabPageLager);
            this.tabControlWrapper.Controls.Add(this.tabPageKomissionierung);
            this.tabControlWrapper.Controls.Add(this.tabPageRezepte);
            this.tabControlWrapper.Controls.Add(this.tabPageControlling);
            this.tabControlWrapper.Location = new System.Drawing.Point(12, 12);
            this.tabControlWrapper.Name = "tabControlWrapper";
            this.tabControlWrapper.SelectedIndex = 0;
            this.tabControlWrapper.Size = new System.Drawing.Size(1001, 717);
            this.tabControlWrapper.TabIndex = 0;
            // 
            // kundenTableAdapter
            // 
            this.kundenTableAdapter.ClearBeforeFill = true;
            // 
            // produkteTableAdapter
            // 
            this.produkteTableAdapter.ClearBeforeFill = true;
            // 
            // bestellungenTableAdapter
            // 
            this.bestellungenTableAdapter.ClearBeforeFill = true;
            // 
            // bestellungEnthaeltTableAdapter
            // 
            this.bestellungEnthaeltTableAdapter.ClearBeforeFill = true;
            // 
            // baeckerei40DataSetBindingSource
            // 
            this.baeckerei40DataSetBindingSource.DataSource = this.baeckerei40DataSet;
            this.baeckerei40DataSetBindingSource.Position = 0;
            // 
            // rohstoffeTableAdapter
            // 
            this.rohstoffeTableAdapter.ClearBeforeFill = true;
            // 
            // rezeptverwaltungBindingSource1
            // 
            this.rezeptverwaltungBindingSource1.DataMember = "Rezeptverwaltung";
            this.rezeptverwaltungBindingSource1.DataSource = this.baeckerei40DataSet;
            // 
            // rezeptverwaltungTableAdapter4
            // 
            this.rezeptverwaltungTableAdapter4.ClearBeforeFill = true;
            // 
            // rezeptverwaltungTableAdapter
            // 
            this.rezeptverwaltungTableAdapter.ClearBeforeFill = true;
            // 
            // RezeptID
            // 
            this.RezeptID.DataPropertyName = "RezeptID";
            this.RezeptID.HeaderText = "RezeptID";
            this.RezeptID.Name = "RezeptID";
            this.RezeptID.ReadOnly = true;
            // 
            // RezeptName
            // 
            this.RezeptName.DataPropertyName = "RezeptName";
            this.RezeptName.HeaderText = "RezeptName";
            this.RezeptName.Name = "RezeptName";
            this.RezeptName.ReadOnly = true;
            // 
            // rohstoffnameDataGridViewTextBoxColumn1
            // 
            this.rohstoffnameDataGridViewTextBoxColumn1.DataPropertyName = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn1.HeaderText = "Rohstoffname";
            this.rohstoffnameDataGridViewTextBoxColumn1.Name = "rohstoffnameDataGridViewTextBoxColumn1";
            this.rohstoffnameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Rohstoffmenge
            // 
            this.Rohstoffmenge.DataPropertyName = "Rohstoffmenge";
            this.Rohstoffmenge.HeaderText = "Rohstoffmenge";
            this.Rohstoffmenge.Name = "Rohstoffmenge";
            this.Rohstoffmenge.ReadOnly = true;
            // 
            // RohstoffEinheit
            // 
            this.RohstoffEinheit.DataPropertyName = "RohstoffEinheit";
            this.RohstoffEinheit.HeaderText = "RohstoffEinheit";
            this.RohstoffEinheit.Name = "RohstoffEinheit";
            this.RohstoffEinheit.ReadOnly = true;
            // 
            // Rohstoffname1
            // 
            this.Rohstoffname1.DataPropertyName = "Rohstoffname1";
            this.Rohstoffname1.HeaderText = "Rohstoffname1";
            this.Rohstoffname1.Name = "Rohstoffname1";
            this.Rohstoffname1.ReadOnly = true;
            // 
            // Rohstoffmenge1
            // 
            this.Rohstoffmenge1.DataPropertyName = "Rohstoffmenge1";
            this.Rohstoffmenge1.HeaderText = "Rohstoffmenge1";
            this.Rohstoffmenge1.Name = "Rohstoffmenge1";
            this.Rohstoffmenge1.ReadOnly = true;
            // 
            // RohstoffEinheit1
            // 
            this.RohstoffEinheit1.DataPropertyName = "RohstoffEinheit1";
            this.RohstoffEinheit1.HeaderText = "RohstoffEinheit1";
            this.RohstoffEinheit1.Name = "RohstoffEinheit1";
            this.RohstoffEinheit1.ReadOnly = true;
            // 
            // Rohstoffname2
            // 
            this.Rohstoffname2.DataPropertyName = "Rohstoffname2";
            this.Rohstoffname2.HeaderText = "Rohstoffname2";
            this.Rohstoffname2.Name = "Rohstoffname2";
            this.Rohstoffname2.ReadOnly = true;
            // 
            // Rohstoffmenge2
            // 
            this.Rohstoffmenge2.DataPropertyName = "Rohstoffmenge2";
            this.Rohstoffmenge2.HeaderText = "Rohstoffmenge2";
            this.Rohstoffmenge2.Name = "Rohstoffmenge2";
            this.Rohstoffmenge2.ReadOnly = true;
            // 
            // RohstoffEinheit2
            // 
            this.RohstoffEinheit2.DataPropertyName = "RohstoffEinheit2";
            this.RohstoffEinheit2.HeaderText = "RohstoffEinheit2";
            this.RohstoffEinheit2.Name = "RohstoffEinheit2";
            this.RohstoffEinheit2.ReadOnly = true;
            // 
            // Rohstoffname3
            // 
            this.Rohstoffname3.DataPropertyName = "Rohstoffname3";
            this.Rohstoffname3.HeaderText = "Rohstoffname3";
            this.Rohstoffname3.Name = "Rohstoffname3";
            this.Rohstoffname3.ReadOnly = true;
            // 
            // Rohstoffmenge3
            // 
            this.Rohstoffmenge3.DataPropertyName = "Rohstoffmenge3";
            this.Rohstoffmenge3.HeaderText = "Rohstoffmenge3";
            this.Rohstoffmenge3.Name = "Rohstoffmenge3";
            this.Rohstoffmenge3.ReadOnly = true;
            // 
            // RohstoffEinheit3
            // 
            this.RohstoffEinheit3.DataPropertyName = "RohstoffEinheit3";
            this.RohstoffEinheit3.HeaderText = "RohstoffEinheit3";
            this.RohstoffEinheit3.Name = "RohstoffEinheit3";
            this.RohstoffEinheit3.ReadOnly = true;
            // 
            // baeckerei40
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 748);
            this.Controls.Add(this.labelBenutzer);
            this.Controls.Add(this.tabControlWrapper);
            this.MaximizeBox = false;
            this.Name = "baeckerei40";
            this.ShowInTaskbar = false;
            this.Text = "Bäckerei 4.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.baeckerei40_FormClosing);
            this.Load += new System.EventHandler(this.baeckerei40_Load);
            this.tabPageControlling.ResumeLayout(false);
            this.tabPageRezepte.ResumeLayout(false);
            this.panelR.ResumeLayout(false);
            this.panelR.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRezpte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rohstoffeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produktEnthaeltBindingSource)).EndInit();
            this.tabPageKomissionierung.ResumeLayout(false);
            this.tabPageLager.ResumeLayout(false);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLager)).EndInit();
            this.tabPageProduktion.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungEnthaeltBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSet)).EndInit();
            this.tabPageBestellung.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bestellungenBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produkteBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridKundenliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).EndInit();
            this.tabControlWrapper.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.baeckerei40DataSetBindingSource)).EndInit();
          //  ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rezeptverwaltungBindingSource3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelBenutzer;
        private System.Windows.Forms.TabPage tabPageControlling;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TabPage tabPageRezepte;
        private System.Windows.Forms.GroupBox panelR;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TabPage tabPageKomissionierung;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabPage tabPageLager;
        private System.Windows.Forms.GroupBox panel;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TabPage tabPageProduktion;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonProduktionSpeichern;
        private System.Windows.Forms.TabPage tabPageBestellung;
        private System.Windows.Forms.ComboBox comboBoxWarenkorbAnzahl;
        private System.Windows.Forms.Button buttonWarenkorbEntfernen;
        private System.Windows.Forms.Button buttonWarenkorbHinzufuegen;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridViewBestellliste;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox listBoxWarenkorb;
        private System.Windows.Forms.Label labelAbholdatum;
        private System.Windows.Forms.DateTimePicker dateTimePickerAbholdatum;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewProduktliste;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonBearbeiten;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.DataGridView dataGridKundenliste;
        private System.Windows.Forms.TextBox textBoxKundennummer;
        private System.Windows.Forms.Label labelKundennummer;
        private System.Windows.Forms.TextBox textBoxTelefonnummer;
        private System.Windows.Forms.Label labelTelefonnummer;
        private System.Windows.Forms.TextBox textBoxNachname;
        private System.Windows.Forms.Label labelNachname;
        private System.Windows.Forms.TextBox textBoxVorname;
        private System.Windows.Forms.Label labelVorname;
        private System.Windows.Forms.Button buttonBestelllisteSpeichern;
        private System.Windows.Forms.TabControl tabControlWrapper;
        private System.Windows.Forms.TextBox textBoxBestellID;
        private System.Windows.Forms.Label labelBestellID;
        private System.Windows.Forms.DataGridViewTextBoxColumn KundenID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Abholdatum;
        private System.Windows.Forms.DataGridViewTextBoxColumn Abholzeit;
        private baeckerei40DataSet baeckerei40DataSet;
        private System.Windows.Forms.BindingSource kundenBindingSource;
        private baeckerei40DataSetTableAdapters.KundenTableAdapter kundenTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kundenIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vornameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nachnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonnummerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pLZDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ortDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource produkteBindingSource;
        private baeckerei40DataSetTableAdapters.ProdukteTableAdapter produkteTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktPreisDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bestellungenBindingSource;
        private baeckerei40DataSetTableAdapters.BestellungenTableAdapter bestellungenTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kundenIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn abholdatumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn abholzeitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dateTimePickerAbholzeit;
        private System.Windows.Forms.Label labelAbholzeit;
        private System.Windows.Forms.BindingSource bestellungEnthaeltBindingSource;
        private baeckerei40DataSetTableAdapters.BestellungEnthaeltTableAdapter bestellungEnthaeltTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellungEnthaeltIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn produktIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bestellMengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn produziertDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridView dataGridViewLager;
        private System.Windows.Forms.BindingSource baeckerei40DataSetBindingSource;
        private baeckerei40DataSet1 baeckerei40DataSet1;
        private System.Windows.Forms.BindingSource rohstoffeBindingSource;
        private baeckerei40DataSet1TableAdapters.RohstoffeTableAdapter rohstoffeTableAdapter;
        private System.Windows.Forms.Button RBearbeiten;
        private System.Windows.Forms.Button RAbbrechen;
        private System.Windows.Forms.Button RHinzufügen;
        private System.Windows.Forms.TextBox RPreis;
        private System.Windows.Forms.TextBox REinheit;
        private System.Windows.Forms.TextBox LMenge;
        private System.Windows.Forms.TextBox RName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labeli;
        private System.Windows.Forms.TextBox RID;
        private System.Windows.Forms.BindingSource produktEnthaeltBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffeinheitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffPreisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lagermengeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button RSpeichern;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource;
        private System.Windows.Forms.DataGridView dataGridViewRezpte;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource1;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource2;
        private System.Windows.Forms.Button RS;
        private System.Windows.Forms.Button RHinzu;
        private System.Windows.Forms.Button RBea;
        private System.Windows.Forms.Button RAbb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox RN1;
        private System.Windows.Forms.TextBox RN2;
        private System.Windows.Forms.TextBox RE1;
        private System.Windows.Forms.TextBox RM2;
        private System.Windows.Forms.TextBox RM1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox RE2;
        private System.Windows.Forms.TextBox RE3;
        private System.Windows.Forms.TextBox RM3;
        private System.Windows.Forms.TextBox RN3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox RezID;
        private System.Windows.Forms.TextBox RM;
        private System.Windows.Forms.TextBox RN;
        private System.Windows.Forms.TextBox RE;
        private System.Windows.Forms.TextBox RezName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource3;
        private baeckerei40DataSet9 baeckerei40DataSet9;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource4;
        private baeckerei40DataSet9TableAdapters.RezeptverwaltungTableAdapter rezeptverwaltungTableAdapter4;
        private baeckerei40DataSet2 baeckerei40DataSet2;
        private System.Windows.Forms.BindingSource rezeptverwaltungBindingSource5;
        private baeckerei40DataSet2TableAdapters.RezeptverwaltungTableAdapter rezeptverwaltungTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn RezeptID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RezeptName;
        private System.Windows.Forms.DataGridViewTextBoxColumn rohstoffnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge2;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffname3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rohstoffmenge3;
        private System.Windows.Forms.DataGridViewTextBoxColumn RohstoffEinheit3;
    }
}

