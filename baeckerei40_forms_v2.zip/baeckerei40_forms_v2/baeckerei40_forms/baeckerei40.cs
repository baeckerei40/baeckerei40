﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baeckerei40_forms
{
    public partial class baeckerei40 : Form
    {

        public baeckerei40(Mitarbeiter m)
        {
            InitializeComponent();
            labelBenutzer.Text = "Benutzer: " + m.Benutzername;
            //Zeige Tabs je nach Berechtigung
            switch (m.Benutzername)
            {
                case "Manager":                    
                    break;
                case "Verkauf":
                    this.tabControlWrapper.TabPages.Remove(tabPageControlling);
                    this.tabControlWrapper.TabPages.Remove(tabPageRohstoffe);
                    this.tabControlWrapper.TabPages.Remove(tabPageProduktion);
                    break;
                case "Bäcker":
                    this.tabControlWrapper.TabPages.Remove(tabPageBestellung);
                    this.tabControlWrapper.TabPages.Remove(tabPageControlling);
                    this.tabControlWrapper.TabPages.Remove(tabPageKomissionierung);
                    break;
                default:
                    break;
            }


        }

        private void buttonHinzufuegen_Click(object sender, EventArgs e)
        {
            try
            {
                Kunde k = new Kunde();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hinzufügen fehlgeschlagen.\n" + ex.Message);
            }
        }

        private void dataGridKundenliste_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            textBoxKundennummer.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBoxVorname.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxNachname.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxTelefonnummer.Text = dataGridKundenliste.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void buttonBearbeiten_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.dataGridKundenliste.EndEdit();
                this.kundenTableAdapter.Update(this.baeckerei40DataSet.Kunden);
                MessageBox.Show("Update successful");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update failed\n" + ex);
            }
        }

        private void dataGridKundenliste_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void baeckerei40_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet4.ProduktEnthaelt". Sie können sie bei Bedarf verschieben oder entfernen.
            //this.produktEnthaeltTableAdapter.Fill(this.baeckerei40DataSet4.ProduktEnthaelt);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet1.Rohstoffe". Sie können sie bei Bedarf verschieben oder entfernen.
            
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet.BestellungEnthaelt". Sie können sie bei Bedarf verschieben oder entfernen.
            this.bestellungEnthaeltTableAdapter.Fill(this.baeckerei40DataSet.BestellungEnthaelt);
            // TODO: Diese Codezeile lädt Daten in die Tabelle "baeckerei40DataSet.Bestellungen". Sie können sie bei Bedarf verschieben oder entfernen.
            this.bestellungenTableAdapter.Fill(this.baeckerei40DataSet.Bestellungen);
            this.produkteTableAdapter.Fill(this.baeckerei40DataSet.Produkte);
            this.kundenTableAdapter.Fill(this.baeckerei40DataSet.Kunden);
            this.rohstoffeTableAdapter.Fill(this.baeckerei40DataSet1.Rohstoffe);
            rohstoffeBindingSource.DataSource = this.baeckerei40DataSet1.Rohstoffe;
        }

        private void buttonBestelllisteSpeichern_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.dataGridViewBestellliste.EndEdit();
                this.bestellungenTableAdapter.Update(this.baeckerei40DataSet.Bestellungen);
                MessageBox.Show("Update successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed\n" + ex);
            }
        }

        private void buttonWarenkorbHinzufuegen_Click(object sender, EventArgs e)
        {
            Produkt p = new Produkt();
            try
            {
                var cellIndex = dataGridViewProduktliste.SelectedCells[0].RowIndex;
                var cellCollection = dataGridViewProduktliste.Rows[cellIndex].Cells[0];

                p.ProduktID = (int)dataGridViewProduktliste.Rows[cellIndex].Cells[0].Value;
                p.Produktname = (string)dataGridViewProduktliste.Rows[cellIndex].Cells[1].Value;
                this.listBoxWarenkorb.Items.Add(p.ProduktID.ToString() + " " + p.Produktname.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kein Produkt ausgewählt. \n" + ex);
            }
        }

        private void baeckerei40_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Alle Forms beenden (auch Login)
            Environment.Exit(0);
        }


        private void RHinzufügen_Click(object sender, EventArgs e)
        {
            try
            {
                panel.Enabled = true;
                RID.Focus();
                this.baeckerei40DataSet1.Rohstoffe.AddRohstoffeRow(this.baeckerei40DataSet1.Rohstoffe.NewRohstoffeRow());
                rohstoffeBindingSource.MoveLast();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rohstoffeBindingSource.ResetBindings(false);
            }
        }

        private void dataGridViewLager_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                RID.Text = dataGridViewLager.Rows[e.RowIndex].Cells[0].Value.ToString();
                RName.Text = dataGridViewLager.Rows[e.RowIndex].Cells[1].Value.ToString();
                REinheit.Text = dataGridViewLager.Rows[e.RowIndex].Cells[2].Value.ToString();
                RPreis.Text = dataGridViewLager.Rows[e.RowIndex].Cells[3].Value.ToString();
                LMenge.Text = dataGridViewLager.Rows[e.RowIndex].Cells[4].Value.ToString();
            }

        }

        private void RBearbeiten_Click(object sender, EventArgs e)
        {
            panel.Enabled = true;
            RID.Focus();

        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Delete)
            {
                if (MessageBox.Show("Sind Sie sicher dass Sie das löschen wollen=", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    rohstoffeBindingSource.RemoveCurrent();
            }
        }

        private void RSpeichern_Click(object sender, EventArgs e)
        {
            try
            {
                rohstoffeBindingSource.EndEdit();
                rohstoffeTableAdapter.Update(this.baeckerei40DataSet1.Rohstoffe);
                panel.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rohstoffeBindingSource.ResetBindings(false);
            }
        }

        private void RAbbrechen_Click(object sender, EventArgs e)
        {
            panel.Enabled = false;
            rohstoffeBindingSource.ResetBindings(false);
        }
    }
}
