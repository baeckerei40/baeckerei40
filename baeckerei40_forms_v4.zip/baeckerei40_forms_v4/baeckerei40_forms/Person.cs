﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baeckerei40_forms
{
    public abstract class Person
    {
        public String Vorname { get; set; }
        public String Nachname{ get; set; }
    }
}
